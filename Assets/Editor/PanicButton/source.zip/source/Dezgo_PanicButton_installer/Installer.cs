﻿/**
  PANIC BUTTON INSTALLER

  This little program will try to find an existing Panic Button installation and overwrite it, or if there is none,
  it will install Panic Button in a default directory.

  The Panic Button files are extracted from Embedded Resources.

  Rationale:
  If the user moved Panic Button to a different directory than the default, then extracted a package
  from the Asset Store (after an update for example), it will extract in the default directory, which will result in the
  presence of two conflicting Panic Button assemblies.
  This installer helper solves this by first trying to locate an existing installation and selecting it as the installation
  target if it exists.
**/
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using System;

namespace Dezgo_PanicButton_installer
{
    [InitializeOnLoad]
    internal static class Installer
    {

        static readonly string DEFAULT_DIRECTORY = "Assets" + Path.DirectorySeparatorChar + "Editor" + Path.DirectorySeparatorChar + "PanicButton";

        /// <summary>
        /// The selected installation target
        /// </summary>
        static string installDirectory = DEFAULT_DIRECTORY; 

        static int state = 0;

        static Installer()
        {
            
            if (File.Exists(".pb.install.disabled"))
            {
                // Used to create the package for upload to the Asset Store
                // If this file is present in the root folder, this will inhibit
                // the installer, and it will remain static for packing it.

                return;
            }

            // Delay the installation in the update loop 
            // (if we don't do it, weird bugs will happen)
            EditorApplication.update += RefreshRequested;
        }

        static bool alwaysForceOverwrite = false;
      

        /// <summary>
        /// Handles user prompt if the file is detected as read-only
        /// </summary>
        /// <param name="filepath"></param>
        /// <param name="action">The action to perform while the file is readable</param>
        /// <returns>true if installation should proceed ; false if it should be canceled</returns>
        static bool HandleFileReadOnly(string filepath, Action action)
        {
            bool handled = false;
            bool shouldContinue = true;           

            while (!handled)
            {
                bool isReadOnly = false;

                if (File.Exists(filepath))
                {
                    isReadOnly = (File.GetAttributes(filepath) & FileAttributes.ReadOnly) != 0;
                }

                if (isReadOnly)
                {
                    var answer = alwaysForceOverwrite ? 2 : EditorUtility.DisplayDialogComplex(
                        "Panic Button installation",
                        
                        "The installer is trying to upgrade this file: " + filepath + "\n\n"+ 
                        "But it is currently marked as read-only.\n"+
                        "If you want to ensure the file is writable yourself (example: you use Perforce), you can do so, then click 'Retry'.\n"+
                        "Or you can click 'Force upgrading all files' and the installer will automatically remove the 'read-only' flag on all files that have it, upgrade, and set the flag back.",
                        
                        "Retry",
                        "Cancel install",
                        "Force upgrading all files");

                    switch (answer)
                    {
                        case 0:
                            // handled is still equal to false,
                            // and we try again at the next loop iteration
                            break;

                        case 1:
                            handled = true;
                            shouldContinue = false;

                            SelfDestruct();
                           
                            throw new InstallationCanceled();
                            break;

                        case 2:
                            alwaysForceOverwrite = true;
                            var amanager = new AttrManager(filepath);

                            action();
                            handled = true;

                            amanager.Close();

                            break;
                    }
                }
                else
                {
                    action();
                    handled = true;
                }
            }

            return shouldContinue;
        }


        static void RefreshRequested()
        {
            switch(state)
            {
                case 0:
                    // Install files in the target directory
                    try
                    {
                        Install();
                    }
                    catch(Exception e) // This makes sure the next state will be executed and that the callback will be unsubsribed
                    {
                        Debug.LogError("Panic Button installer: Unhandled exception: " + e.ToString());
                    }
                    break;

                default:
                    // Unsubscribe from the callback
                    EditorApplication.update -= RefreshRequested;

                    // Force Unity to refresh, causing the load of Panic Button
                    AssetDatabase.Refresh();
                    break;
            }

            state++;
        }



        static void Install()
        {
            bool existsInDefaultDir = File.Exists(  Path.Combine(DEFAULT_DIRECTORY , "Dezgo_PanicButton.dll")   );

            // try to find an existing install directory if there's nothing in the default dir
            if (!existsInDefaultDir)
            {
                foreach (var f in EnumerateAllFiles("Assets"))
                {
                    if (Path.GetFileName(f) == "Dezgo_PanicButton.dll")
                    {
                        installDirectory = Path.GetDirectoryName(f);
                        Debug.Log("PanicButton upgrade: found an existing installation in the following folder, will install here:\n" + installDirectory);

                        // Copy the other misc files (MacHotKeys, documentation.pdf, source.zip) to the other dir

                        try
                        {
                            CopyFromDefault("MacHotKeys");
                            CopyFromDefault("documentation.pdf");
                            CopyFromDefault("source.zip");
                        }
                        catch(InstallationCanceled)
                        {
                            return;
                        }

                        break;
                    }
                }
            }

            // Create subdirectories if necessary, and copy files from resources to filesystem
            Directory.CreateDirectory(installDirectory);
            try
            {
                CopyResToFile("Dezgo_PanicButton.dll");
                CopyResToFile("Dezgo_PanicButton.dll.mdb");
            }
            catch(InstallationCanceled)
            {
                return;
            }

            SelfDestruct();

            // destruct the default folder IF AND ONLY IF it is empty
            DeleteDirectoryIfEmpty(DEFAULT_DIRECTORY);
        }

        private static bool alreadyDestructed = false;
        private static void SelfDestruct()
        {
            if (!alreadyDestructed)
            {
                File.Delete(System.Reflection.Assembly.GetExecutingAssembly().Location);
                alreadyDestructed = true;
            }
        }

        private static void DeleteDirectoryIfEmpty(string dirpath)
        {
            if (Directory.Exists(dirpath) == false)
                return;

            int count = CountFilesystemEntriesExcludingMeta(dirpath);

            //Debug.LogWarning(count);

            if (count == 0)
            {
                Directory.Delete(dirpath, true);
            }
        }

        private static int CountFilesystemEntriesExcludingMeta(string dirpath)
        {
            int count = 0;

            foreach( var f in Directory.GetFileSystemEntries(dirpath) )
            {
                if (Path.GetExtension(f) != ".meta")
                    count++;
            }

            return count;
        }

        private static void CopyFromDefault(string filename)
        {
            var from = Path.Combine(DEFAULT_DIRECTORY, filename);
            var to = Path.Combine(installDirectory, filename);

            if (File.Exists(from))
            {
                try
                {
                    HandleFileReadOnly(to, () => File.Copy(from, to, true));
                }
                catch(InstallationCanceled)
                {
                    throw;
                }
                catch(Exception e)
                {
                    Debug.LogError("PanicButton upgrade: Couldn't copy file from the default install folder to the existing install folder:\n" +
                        from + " > " + to + "\n" +
                        "\nException thrown: " +
                        e.ToString());
                    return;
                }
            }

            try { File.Delete(from); } catch { }
        }

        static IEnumerable<string> EnumerateAllFiles(string directory)
        {
            var pending = new Queue<string>();
            pending.Enqueue(directory);

            while (pending.Count > 0)
            {
                var cur = pending.Dequeue();

                foreach (var f in Directory.GetFiles(cur))
                {
                    yield return f;
                }

                foreach (var dir in Directory.GetDirectories(cur))
                {
                    pending.Enqueue(dir);
                }
            }
        }

        /// <summary>
        /// Copy the given file from embedded resources to filesystem in the target directory
        /// </summary>
        /// <param name="file"></param>
        static void CopyResToFile(string file)
        {
            var data = GetResource(file);
            var filepath = Path.Combine(installDirectory, file);

            // Write to a temp file
            try
            {
                
                using (var f = File.Open(filepath + ".tmp", FileMode.Create, FileAccess.Write, FileShare.Read))
                {
                    f.Write(data, 0, data.Length);
                }
                
            }
            catch(Exception e)
            {
                Debug.LogError("PanicButton upgrade: couldn't write the updated file to disk: " + file + "\n" +
                    "\nException thrown: " + e.ToString());
                return;
            }

            try
            {
                HandleFileReadOnly(filepath, () =>
                {
                    // Delete the old file
                    File.Delete(filepath);

                    // Rename the temp file to the final file
                    File.Move(filepath + ".tmp",
                              filepath);
                });
            }
            catch(InstallationCanceled)
            {
                throw;
            }
            catch(Exception e)
            {
                Debug.LogError("PanicButton upgrade: couldn't overwrite the old file with the new temp file: "+ file+".tmp" + "\n"+
                    "This can happen if another program still has the old file opened. Maybe you can try to do this manually by just removing the '.tmp' extension? \n" +
                    "\nException thrown: " + e.ToString());
                return;
            }
        }

        /// <summary>
        /// Fetch the given resource
        /// </summary>
        /// <param name="resName"></param>
        /// <returns></returns>
        static byte[] GetResource(string resName)
        {
            var s = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Dezgo_PanicButton_installer." + resName);

            var buffer = new byte[s.Length];

            s.Read(buffer, 0, buffer.Length);

            return buffer;
        }
    }
}
