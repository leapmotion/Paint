﻿using System;
using System.Runtime.Serialization;

namespace Dezgo_PanicButton_installer
{
    [Serializable]
    internal class InstallationCanceled : Exception
    {
        public InstallationCanceled()
        {
        }

        public InstallationCanceled(string message) : base(message)
        {
        }

        public InstallationCanceled(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InstallationCanceled(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}