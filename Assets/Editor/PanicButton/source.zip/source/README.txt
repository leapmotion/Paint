How to build Panic Button ?
===

- Open the solution "PanicButton_source/Dezgo_PanicButton.sln" in Visual Studio
- Ensure that ILMerge and pdb2mdb are accessible on the command line*
- Check that the paths to Unity's assemblies in the post-build event are correct (for both projects)
- Build the solution
- Copy the output of the "Dezgo_PanicButton_installer" project (PanicButton.dll) in a Unity project


HOW THE SOLUTION IS STRUCTURED

In dependency order, the first project "Dezgo_PanicButton" contains the actual code of PanicButton.
It is built and merged with its dependencies in a single DLL. 
Its debug file is also converted in the MDB format to be compatible with Unity.

Then, the project "Dezgo_PanicButton_installer" is a utility DLL that controls the installation process.
It contains the previous project output within it as embedded resources.
At runtime, it automatically extracts the Panic Button in the correct directory and deletes itself.

Rebuilding the solution performs all the steps in the correct order to produce the final output.

For more information about the details, see the pre/post build events and the source code.

===
*
ILMerge is a tool for combining multiple assemblies into one.
Download: http://www.microsoft.com/en-us/download/details.aspx?id=17630

pdb2mdb translates pdb files (which are compatible only with Microsoft's .NET implementation) to
mdb files (which are compatible with Mono's .NET implementation).
Unity is based on Mono, so it needs mdb files, while Visual Studio is generating pdb files.
This tool allows to close the gap.
pdb/mdb files contain debugging information, this is what allows to have line number information
in stack trace logs.
Download: https://www.nuget.org/packages/Mono.pdb2mdb/

