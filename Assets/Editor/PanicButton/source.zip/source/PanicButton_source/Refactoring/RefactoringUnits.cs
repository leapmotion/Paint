﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */
using System;
using System.Collections.Generic;
using System.Linq;

using Mono.Cecil;
using Mono.Cecil.Cil;
using Mono.Cecil.Rocks;

namespace Dezgo.Panic
{
    /// <summary>
    /// Collection of refactoring subprograms
    /// </summary>
    static class RefactoringUnits
    {
        private static readonly string PANIC_INSTRUCTION_MARK = "panic://";

        /// <summary>
        /// Transpose an Instruction given a transposition table.
        /// The Instruction reference that is returned will be unchanged if it's null or inexistent in the transposition
        /// table.
        /// </summary>
        /// <param name="oldToNew">the transposition table</param>
        /// <param name="field">the reference contained in a field pointing to an instruction</param>
        /// <returns>the new value that shall be associated to the field</returns>
        private static Instruction TransposeField(Dictionary<Instruction, Instruction> oldToNew, Instruction field)
        {
            if (field != null)
            {
                if (oldToNew.ContainsKey(field))
                {
                    return oldToNew[field];
                }
            }

            return field;
        }

        /// <summary>
        /// Transpose all instruction references in a method's data structures, given a transposition table.
        /// This method will update exception handlers, scopes, and operands pointing to Instructions.
        /// </summary>
        /// <param name="oldToNew">a transposition table</param>
        /// <param name="method">the targeted method</param>
        private static void TransposeInstructions(Dictionary<Instruction, Instruction> oldToNew, MethodDefinition method)
        {
            // If there is no body, then there is no data structure to update
            if (!method.HasBody)
                return;

            // A- Process exception handlers
            if (method.Body.HasExceptionHandlers)
            {
                foreach (var handler in method.Body.ExceptionHandlers)
                {
                    handler.FilterStart = TransposeField(oldToNew, handler.FilterStart);
                    handler.HandlerEnd = TransposeField(oldToNew, handler.HandlerEnd);
                    handler.HandlerStart = TransposeField(oldToNew, handler.HandlerStart);
                    handler.TryEnd = TransposeField(oldToNew, handler.TryEnd);
                    handler.TryStart = TransposeField(oldToNew, handler.TryStart);
                }
            }


            /* B- Process operands */
            foreach (var i in method.Body.Instructions)
            {
                // Do not touch injected instructions, otherwise it will result in garbage
                if (i?.SequencePoint?.Document?.Url == PANIC_INSTRUCTION_MARK)
                    continue;

                if (i.Operand is Instruction)
                {
                    i.Operand = TransposeField(oldToNew, (Instruction)i.Operand);
                }
                else if (i.Operand is Instruction[])
                {
                    var newOperands = new List<Instruction>();
                    foreach (var suboperand in (Instruction[])i.Operand)
                    {
                        newOperands.Add(TransposeField(oldToNew, suboperand));
                    }
                    i.Operand = newOperands.ToArray();
                }
            }


            /* C- Process scopes */
            TransposeScope(oldToNew, method.Body.Scope);

        }

        /// <summary>
        /// Transpose a Scope data structure and all nested Scopes given a transposition table.
        /// </summary>
        /// <param name="oldToNew">the transposition table</param>
        /// <param name="scope">a Scope data structure</param>
        private static void TransposeScope(Dictionary<Instruction, Instruction> oldToNew, Scope scope)
        {
            if (scope != null)
            {
                scope.Start = TransposeField(oldToNew, scope.Start);
                scope.End = TransposeField(oldToNew, scope.End);

                if (scope.HasScopes)
                {
                    foreach (var sub in scope.Scopes)
                    {
                        TransposeScope(oldToNew, sub);
                    }
                }
            }
        }

        /// <summary>
        /// (DEPRECATED)
        /// Alter the code of a method, to add a call to another method at each control flow branch.
        /// </summary>
        /// <param name="method">The method where calls must be added</param>
        /// <param name="callTo">The method that the calls must invoke</param>
        [Obsolete("Use ProcessMethod_MAIN() and not call-based system, but ldsfld+brfalse+call")]
        private static void ProcessMethod_AddJumpCalls(MethodDefinition method, MethodReference callTo)
        {
            var transpositionTable = new Dictionary<Instruction, Instruction>();



            // List of instructions before which a call must be inserted
            var targetInstructions = new List<Instruction>();

            for (int idx = 0; idx < method.Body.Instructions.Count; idx++)
            {
                var i = method.Body.Instructions[idx];
                var op = i.OpCode;

                if (op.FlowControl == Mono.Cecil.Cil.FlowControl.Branch ||
                    op.FlowControl == Mono.Cecil.Cil.FlowControl.Cond_Branch)
                {


                    //if(IsBackwardsJump(i))
                    targetInstructions.Add(i);
                }
            }

            // Once we have determined all instructions that alter the control flow, 
            // we can add a call to "callTo" before each one of them

            var processor = method.Body.GetILProcessor();

            foreach (var instHolder in targetInstructions)
            {
                var inst = instHolder;

                var newInstruction = processor.Create(Mono.Cecil.Cil.OpCodes.Call, callTo);
                //newInstruction.SequencePoint = instHolder.relevantSeqPoint; // 1.0.2
                processor.InsertBefore(inst, newInstruction);

                transpositionTable[inst] = newInstruction;

                // If the control flow operand is an instruction, and that this instruction points to itself
                // then it will leave no chance to "callTo" being called at each iteration,
                // so we change the operand to point to the newInstruction making the call in this case
                if (inst.Operand is Mono.Cecil.Cil.Instruction)
                {
                    if (inst.Operand == inst)
                    {
                        inst.Operand = newInstruction;
                    }
                }
            }


            TransposeInstructions(transpositionTable, method);
        }

        /// <summary>
        /// Injects all safe-keeping code in the given *method*.
        /// </summary>
        /// <param name="method">The method to protect</param>
        /// <param name="triggerField">a reference to a field, that when true will call *callTo*</param>
        /// <param name="callTo">the method that must be called when *triggerField* is true</param>
        internal static void ProcessMethod_MAIN(MethodDefinition method, FieldReference triggerField, MethodReference callTo)
        {
            if (method.HasBody)
            {
                if (method.Body.Instructions.Count > 0)
                {
                    SequencePoint firstLine = Refactory.CopySeqPoint(Refactory.FindFirstLineOfMethod(method));

                    // Normalize all opcodes to long-form
                    // so that offsets can grow without overflowing the limited range
                    // of short-form opcodes
                    method.Body.SimplifyMacros();

                                       
                    // Create panic instructions at each backward control flow branch
                    RefactoringUnits.CreatePanicAtBranches(triggerField, callTo, method.Body);


                    // Create a panic instruction at the beginning of the method
                    RefactoringUnits.CreatePanicInstruction(null, triggerField, callTo, method.Body.GetILProcessor(), null, firstLine);


                    // Injected panic instructions will have a "panic mark" in the form of a sequence point
                    // pointing a special document URL "panic://"
                    // Before finalizing the method, these are removed
                    DeletePanicMarks(method.Body);

                    // DEPRECATED!
                    // This method injected only 1 instruction consisting of a "call" opcode to a special method.
                    // This had the drawback of creating new stackframes which would pollute the step-by-step 
                    // debugginng experience at each call and control flow branch.
                    // The new refactoring units do all the work in the injected code in 3 instructions (ldsfld+brfalse+call)
                    //RefactoringUnits.ProcessMethod_AddJumpCalls(method, callTo);

                    // Optimize opcodes where it's possible (long-form to short-form)
                    method.Body.OptimizeMacros();
                }
            }
        }

        /// <summary>
        /// Delete sequence points markers in panic button marked instructions
        /// </summary>
        /// <param name="body">the body of a method</param>
        private static void DeletePanicMarks(MethodBody body)
        {
            foreach (var i in body.Instructions)
            {
                if (i?.SequencePoint?.Document?.Url == PANIC_INSTRUCTION_MARK)
                {
                    i.SequencePoint = null;

                    // try to find a sequence point to associate to the call, so that line numbers
                    // show up correctly when the PanicAbortException is thrown
                    if(i.OpCode == OpCodes.Brfalse || i.OpCode == OpCodes.Brfalse_S)
                    {
                        var relevantSeqPoint = Refactory.FindSeqPointAbove((Instruction)i.Operand);
                        i.Next.SequencePoint = Refactory.CopySeqPoint(relevantSeqPoint);
                    }
                }
            }
        }

        /// <summary>
        /// Returns true if the given instruction is a backwards jump to a previous instruction.
        /// </summary>
        /// <param name="i">the instruction to inspect</param>
        /// <returns>true if the jump refers to a previous instruction</returns>
        private static bool IsBackwardsJump(Instruction i)
        {
            if (i.Operand is Instruction)
            {
                return ((Instruction)i.Operand).Offset <= i.Offset;
            }
            else
            {
                // If we cannot determine, then we return true by default,
                // because this method is used to filter branch instructions that should be protected or not
                // so true will just maximize the number of these instructions
                return true;
            }
        }

        /// <summary>
        /// foobar<para/>
        /// barfoo
        /// </summary>
        static void Foobar()
        {

        }

        /// <summary>
        /// Protects the given *target* instruction by injecting panic instructions just before it.
        /// The injected instructions are the following:
        /// 
        /// <para>.volatile               - a prefix for the load field so that the value is not cached.</para>
        /// <para>ldsfld triggerField     - load the value of the control field on the stack.</para>
        /// <para>brfalse target          - jumps to the targeted instruction if the trigger is not activated.</para>
        /// <para>call triggerMethod      - calls the handling method if the trigger is activated.</para>
        /// <para>[original targeted instruction]</para>
        /// </summary>
        /// <param name="transpositionTable">a transposition table to fill, mapping protected instructions, to the head of injected instructions</param>
        /// <param name="triggerField">a reference to a field, that when true will call triggerMethod</param>
        /// <param name="triggerMethod">a reference to a method, that will be called when triggerFeild is true</param>
        /// <param name="il">an existing ILProcessor for the method in which the targeted instruction is</param>
        /// <param name="target">An instruction before which panic instructions will be inserted</param>
        /// <param name="sequenceInfo">The sequence point to associate to the injected instructions. WARNING!!! : If this parameter is supplied or not-null, then the injected instructions won't be marked as panic instructions</param>
        private static void CreatePanicInstruction(Dictionary<Instruction, Instruction> transpositionTable, FieldReference triggerField, MethodReference triggerMethod, ILProcessor il, Instruction target, SequencePoint sequenceInfo = null)
        {
            bool noTarget = target == null;

            // Parameter checks
            if ((transpositionTable == null) ^ (target == null))
            {
                throw new ArgumentException(string.Format("If there is a transposition table, there must be a target instruction and vice-versa. One of the parameters is null.\nTransposition table: {0} ; Target: {1}", transpositionTable, target));
            }

            // If no target is supplied, we just insert instructions at the beginning of the method
            if (noTarget)
            {
                target = il.Body.Instructions[0];
            }

            var loadValue = Instruction.Create(OpCodes.Ldsfld, triggerField);
            il.InsertBefore(target, loadValue);

            var branch = Instruction.Create(OpCodes.Brfalse, target);
            il.InsertAfter(loadValue, branch);

            var call = Instruction.Create(OpCodes.Call, triggerMethod);
            il.InsertAfter(branch, call);

            var vol = Instruction.Create(OpCodes.Volatile);
            il.InsertBefore(loadValue, vol);

            var HEAD = vol;

            if (!noTarget)
            {
                // This must be done only if there is an actual target
                if (target.Operand is Instruction)
                {
                    // Avoid single-instruction infinite loops
                    if (target.Operand == target)
                        target.Operand = HEAD;
                }
            }

            if (transpositionTable != null)
            {
                transpositionTable[target] = HEAD;
            }

            if (sequenceInfo != null)
            {
                vol.SequencePoint = Refactory.CopySeqPoint(sequenceInfo);
                loadValue.SequencePoint = Refactory.CopySeqPoint(sequenceInfo);
                branch.SequencePoint = Refactory.CopySeqPoint(sequenceInfo);
                call.SequencePoint = Refactory.CopySeqPoint(sequenceInfo);
            }
            else
            {
                Mark(vol);
                Mark(loadValue);
                Mark(branch);
                Mark(call);
            }
        }

        /// <summary>
        /// Marks the given instruction as being "panic button-injected"
        /// </summary>
        /// <param name="i">an instruction emitted by panic button</param>
        private static void Mark(Instruction i)
        {
            // The mark is implemented as a SequencePoint pointing
            // to a special Document URL
            i.SequencePoint = new SequencePoint(new Document(PANIC_INSTRUCTION_MARK));
        }

        /// <summary>
        /// Test refactoring. Do not use in production.
        /// </summary>
        /// <param name="body"></param>
        private static void Dummy(MethodBody body)
        {
            var il = body.GetILProcessor();

            var head = body.Instructions.First();

            for (int i = 0; i < 10; i++)
            {
                il.InsertBefore(head, Instruction.Create(OpCodes.Ldc_I4, 42));
                il.InsertBefore(head, Instruction.Create(OpCodes.Pop));

                //il.InsertBefore(head, Instruction.Create(OpCodes.Pop));
                //il.InsertBefore(head, Instruction.Create(OpCodes.Ldc_I4, 42));
            }
        }

        /// <summary>
        /// Inject panic button instructions at each control flow branch
        /// </summary>
        /// <param name="triggerField">The field for controlling panic button</param>
        /// <param name="triggerMethod">The handling method if the field is true</param>
        /// <param name="body">A method body to protect</param>
        private static void CreatePanicAtBranches(FieldReference triggerField, MethodReference triggerMethod, MethodBody body)
        {
            var transpositionTable = new Dictionary<Instruction, Instruction>();

            var instructions = new List<Instruction>(body.Instructions);
            var il = body.GetILProcessor();

            foreach (var i in instructions)
            {
                bool doThisInstruction = false;

                // If an instruction is a branch...
                if (i.OpCode.FlowControl == FlowControl.Branch ||
                    i.OpCode.FlowControl == FlowControl.Cond_Branch)
                {
                    // And that this branch is looping back...
                    if (IsBackwardsJump(i))
                    {
                        // And that this branch is user-code, and not a panic button-generated instruction...
                        if (i?.SequencePoint?.Document?.Url != PANIC_INSTRUCTION_MARK)
                        {
                            doThisInstruction = true;
                        }
                    }
                }

                if(!doThisInstruction)
                {
                    // If this instruction is the first of an exception handler block
                    if(IsInstructionHeaderOfAnExceptionBlock(body, i))
                    {
                        doThisInstruction = true;
                    }
                }


                if(doThisInstruction)
                    CreatePanicInstruction(transpositionTable, triggerField, triggerMethod, il, i);
            }

            TransposeInstructions(transpositionTable, body.Method);
        }

        /// <summary>
        /// Determines if this instruction is the first one of an exception handler block in the provided method body.
        /// </summary>
        /// <param name="body">The method body in which this instruction resides</param>
        /// <param name="i">An instruction</param>
        /// <returns>true if this instruction is the header of one of the handlers in the method ; false if not or if there is no handler</returns>
        private static bool IsInstructionHeaderOfAnExceptionBlock(MethodBody body, Instruction i)
        {
            if (body.HasExceptionHandlers)
            {
                foreach (var handler in body.ExceptionHandlers)
                {
                    // I think it is not necessary to do handler.FilterStart, because these are pretty simple routines mapping to boolean expressions
                    // And I'm not sure about the stack requirements.
                    // Anyway, if there is really a backward jump in it, it will already be protected.

                    if (i == handler.HandlerStart) return true; 
                }
            }

            return false;
        }

    }
}
