﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;

using Mono.Cecil;
using Mono.Cecil.Rocks;

namespace Dezgo.Panic
{
    
    class Refactory
    {
        /// <summary>
        /// Lines marked with this number are considered "hidden" to the debugger, and as such, we cannot retrieve a real line number
        /// if it is set to this constant.
        /// </summary>
        const int hiddenDebuggerLines = 0xFEEFEE;

        #region Static fields
        /// <summary>
        /// Setting this field to true will force refactoring of every assembly.
        /// If it's false, assemblies that are already recompiled will not be processed again.
        /// This field will be reset to false after each refactoring operation.
        /// </summary>
        public static volatile bool forceRecompileEverything = false; 
        
        /// <summary>
        /// If there is an embedded resource with this key in an assembly, this means it has already been processed.
        /// </summary>
        static readonly string markerKey = "DEZGO_WATCHDOG_PROCESSED";

        /// <summary>
        /// If there is an embedded resource with this key in an assembly, this means it has already been processed.
        /// (alternative key)
        /// </summary>
        static readonly string altMarkerKey = "Dezgo.Panic.DEZGO_WATCHDOG_PROCESSED";


        /// <summary>
        /// The key of an embedded resource inside a processed assembly, that contains the complete data of the original assembly from which it was derived.
        /// This is used when forcing a recompilation of the assembly, to have the original assembly again to restart the process,
        /// or to revert it to its original state when requested by the user.
        /// </summary>
        static readonly string inputDataKey = "DEZGO_PANICBUTTON_INPUT_ASSEMBLY_DATA";
        #endregion

        #region Instance fields
        /// <summary>
        /// The path to the Unity project.
        /// </summary>
        string pathToProject;

        /// <summary>
        /// The collection of all paths from which to resolve assemblies
        /// </summary>
        HashSet<string> resolvingPaths = null;

        /// <summary>
        /// The Cecil assembly resolver
        /// </summary>
        IAssemblyResolver cachedResolver = null;

        /// <summary>
        /// Post-processing delegates list to apply final steps to an assembly after it has been processed
        /// </summary>
        List<Action<ModuleDefinition>> postProcessing = new List<Action<ModuleDefinition>>();

        /// <summary>
        /// Synchronization object for locking.
        /// </summary>
        object _sync = new object();

        /// <summary>
        /// Path to a file whose presence indicates that the ScriptAssemblies have been processed.
        /// If it disappears, a refactoring should be triggered again.
        /// </summary>
        private static readonly string PROCESSED_TOKEN_FILEPATH = Utils.MakePath("Library", "ScriptAssemblies", ".panicbutton");
        
        
        /// <summary>
        /// The path to the file that indicated if DLL files were found.
        /// </summary>
        internal static readonly string isDllCacheFilePath = Utils.MakePath("Library", ".panicbutton.dllfound");
        private static readonly string TEXT_FILE_OPENED_IN_ANOTHER_PROGRAM= "This file is opened in another program, so it can't be updated. Please make sure no other program has this file opened.";

        

        #endregion

        #region Static methods

        /// <summary>
        /// Refactor assemblies of a Unity project to add instrumentation code calling the Panic Button RuntimeSystem
        /// </summary>
        /// <param name="pathToProject">A path to the root of the Unity project (where folders like Assets/ or Library/ can be found)</param>
        /// <param name="settings">The settings to honor</param>
        public static void Refactor(string pathToProject, PanicSettings settings)
        {
            // Just measure how long it takes
            var processingTime = new System.Diagnostics.Stopwatch();
            processingTime.Start();

            // Scan the Assets/ folder to find external DLLs
            var assetsDLL = new HashSet<string>();
            foreach(var i in FindDLLs(Utils.MakePath(pathToProject, "Assets")))
            {
                assetsDLL.Add( Path.GetFullPath(i) );
            }

            // Cache the result to avoid rescanning for DLL files for DLLPrompt
            try
            {
                using (var isDllCacheFile = File.Open(isDllCacheFilePath, FileMode.Create, FileAccess.Write))
                {
                    bool thereIsDll = assetsDLL.Count > 0;

                    if (assetsDLL.Count == 1 && Path.GetFileName(assetsDLL.ToArray()[0]) == "Dezgo_PanicButton.dll")
                        thereIsDll = false;

                    isDllCacheFile.WriteByte((byte)(thereIsDll ? 1 : 0));

                    int pid = System.Diagnostics.Process.GetCurrentProcess().Id;
                    var pidBytes = BitConverter.GetBytes(pid);
                    isDllCacheFile.Write(pidBytes, 0, pidBytes.Length);
                }
            }
            catch
            {
                // The success of this operation is not important
            }



            // Instantiate the Refactory instance
            var refactory = new Refactory();

            // CONFIG - set the path to project
            refactory.pathToProject = pathToProject;

            var pathToScriptAssemblies = Utils.MakePath(refactory.pathToProject, "Library", "ScriptAssemblies");
            var scriptAssemblies = FindDLLs(pathToScriptAssemblies);

            // CONFIG - set the resolving paths to Unity Assemblies
            refactory.resolvingPaths = new HashSet<string>();
            refactory.resolvingPaths.Add(Path.GetDirectoryName(typeof(UnityEngine.Application).Assembly.Location));
            refactory.resolvingPaths.Add(Path.GetDirectoryName(typeof(UnityEditor.EditorApplication).Assembly.Location));

            refactory.resolvingPaths.Add(Path.GetDirectoryName(typeof(System.Array).Assembly.Location));
            refactory.resolvingPaths.Add(Path.GetDirectoryName(typeof(System.Runtime.GCSettings).Assembly.Location));
            

            

            // CONFIG - then resolving paths to ScriptAssemblies
            foreach (var dllPath in scriptAssemblies)
                refactory.resolvingPaths.Add(Path.GetDirectoryName(dllPath));

            // CONFIG - ... and Assets assemblies
            foreach (var dllPath in assetsDLL)
                refactory.resolvingPaths.Add(Path.GetDirectoryName(dllPath));


            // PROCESSING
            HashSet<string> dllPathsToProcess ;

            // Protects external DLLs
            {
                // List of items to process

                var selectedDLLs = new HashSet<string>();
                foreach(var i in settings.protectedDLLs)
                    selectedDLLs.Add(Path.GetFullPath(i));
                

                foreach (var i in assetsDLL)
                {
                    if (settings.protectAllDLLs || selectedDLLs.Contains(i))
                    {
                        bool wasProcessed;

                        
                        refactory.ProcessAssembly(i, out wasProcessed);
                        if(wasProcessed)
                            Utils.Log(Logging.User, "Protected DLL: {0}", i);
                    }
                    else
                    {
                        // If this DLL is not protected according to the current settings, we revert it

                        bool canIgnore = false;

                        try { canIgnore = CanWeIgnoreThisAssemblyForRevert(i); }
                        catch(Exception e) {}

               


                        if (!canIgnore)
                        {

                            bool revertReturnVal = false;
                            try
                            {
                                revertReturnVal = RevertAssembly(i);
                            }
                            catch (Exception e)
                            {
                                string helpfulText = "";

                                // Provide a helpful text for common errors like sharing violation 
                                if(IsSharingViolation(e))
                                    helpfulText = TEXT_FILE_OPENED_IN_ANOTHER_PROGRAM;


                                Utils.LogError(Logging.User, "Cannot open this assembly for looking if we need to revert it: {2}\n=> {0}\nException thrown during reading of the assembly:\n{1}", i, e, helpfulText);
                            }

                            if (revertReturnVal)
                                Utils.Log(Logging.User, "Reverted DLL: {0}", i);
                        }
                    }
                } 
            }
            
            // Process each dll in ScriptAssembies
            foreach(var dllPath in scriptAssemblies)
            {
                bool unusedVar;
                refactory.ProcessAssembly(dllPath, out unusedVar);
            }

       

            MarkScriptAssembliesAsProcessed();

            forceRecompileEverything = false;

            processingTime.Stop();
            Utils.Log(Logging.Dev, "Refactoring DONE in {0} ms", processingTime.ElapsedMilliseconds);
        }

        private static bool IsSharingViolation(Exception e)
        {
            bool output = false;

            if (e is System.IO.IOException)
            {
                var io = ((System.IO.IOException)e);

                int HResult = System.Runtime.InteropServices.Marshal.GetHRForException(io);
                const int SharingViolation = 32;
                if ((HResult & 0xFFFF) == SharingViolation)
                {
                    output = true;
                }
            }

            return output;
        }


        /// <summary>
        /// Find all DLLs in a path and its subdirectories
        /// </summary>
        /// <param name="rootPath">The root path</param>
        /// <param name="alsoDotExe">if true : also enumerates .exe files</param>
        /// <returns>An enumeration of all found DLL paths</returns>
        internal static IEnumerable<string> FindDLLs(string rootPath, bool alsoDotExe = false)
        {
            foreach(var f in FindDLLs_All(rootPath, alsoDotExe))
            {
                if (Path.GetFileName(f) == "Dezgo_PanicButton_asset.dll")
                    continue;

                // Only return managed assemblies
                if (Mono.Reflection.Image.IsAssembly(f))
                    yield return f;
               
            }
        }

        private static IEnumerable<string> FindDLLs_All(string rootPath, bool alsoDotExe = false)
        {
            var listDLL =  Directory.GetFiles(rootPath, "*.dll", SearchOption.AllDirectories);
        
            if(alsoDotExe)
            {
                var listEXE = Directory.GetFiles(rootPath, "*.exe", SearchOption.AllDirectories);

                return listDLL.Concat(listEXE);
            }
            else
            {
                return listDLL;
            }
        }

        /// <summary>
        /// Determines if a specified type is inheriting directly or indirectly from the specified fullname of another type.
        /// </summary>
        /// <param name="type">the type that you want to know if it inherits from baseTypeFullName</param>
        /// <param name="baseTypeFullName">the fullname of a potentiall base type</param>
        /// <returns>true if "type" inherits directly or indirectly from "baseTypeFullName"</returns>
        static bool IsInheritingFrom(TypeDefinition type, string baseTypeFullName)
        {
            if(type.BaseType == null)
                return false;

            while(true)
            {
                if (type.FullName == baseTypeFullName)
                    return true;

                if (type.BaseType == null)
                    break;

                try
                {
                    type = type.BaseType.Resolve();
                }
                catch
                {
                    return false;   
                }
            }

            return false;
        }


        /// <summary>
        /// Returns the SequencePoint corresponding to the topmost line number in this method if any or null if none are found.
        /// Added in fix 1.0.2. 
        /// </summary>
        /// <param name="method"></param>
        /// <returns>the sequence point found or null if none</returns>
        internal static Mono.Cecil.Cil.SequencePoint FindFirstLineOfMethod(MethodDefinition method)
        {
            Mono.Cecil.Cil.SequencePoint best = null;

            if(method.HasBody)
            {
                foreach(var i in method.Body.Instructions)
                {
                    if(i.SequencePoint != null)
                    {
                        if(i.SequencePoint.StartLine != hiddenDebuggerLines)
                        {
                            if (best == null)                                    best = i.SequencePoint;
                            else if (i.SequencePoint.StartLine < best.StartLine) best = i.SequencePoint;
                        }
                    }
                }
            }

            return best;
        }

        /// <summary>
        /// Find the first sequence point above the given instruction.
        /// Added in fix 1.0.2.
        /// </summary>
        /// <param name="i">An instruction above which to search</param>
        /// <returns>the sequence point found or null if none</returns>
        internal static Mono.Cecil.Cil.SequencePoint FindSeqPointAbove(Mono.Cecil.Cil.Instruction i)
        {
            while (i.SequencePoint == null || i?.SequencePoint?.Document?.Url == "panic://")
            {
                //if (IsJumpTarget(i))
                //    return null;

                i = i.Previous;
                if (i == null)
                    return null;

                
            }

            return i.SequencePoint;
        }

        /// <summary>
        /// Alter the code of a method, to add a call to another method just as the first instruction.
        /// </summary>
        /// <param name="method">The method where the call must be added</param>
        /// <param name="callTo">The method that the call must invoke</param>
        static void ProcessMethod_AddCallBeginning(MethodDefinition method, MethodReference callTo)
        {
            // Fix 1.0.2
            var firstLineSeqPoint = FindFirstLineOfMethod(method);

            if (method.HasBody)
            {
                if (method.Body.Instructions.Count > 0)
                {
                    var processor = method.Body.GetILProcessor();
                    var newInstruction = processor.Create(Mono.Cecil.Cil.OpCodes.Call, callTo);
                    var firstInstruction = method.Body.Instructions[0];

                    // Fix 1.0.2: Ensure the new instruction has debugging data corresponding to the beginning of the method
                    newInstruction.SequencePoint = CopySeqPoint(firstLineSeqPoint);

                    processor.InsertBefore(firstInstruction, newInstruction);
                }
            }
        }

        internal static Mono.Cecil.Cil.SequencePoint CopySeqPoint(Mono.Cecil.Cil.SequencePoint O, int incr = 0)
        {
            if (O == null)
                return null;

            var output = new Mono.Cecil.Cil.SequencePoint(CopyDoc(O.Document));

            output.EndColumn = O.EndColumn;
            output.EndLine = O.EndLine + incr;
            output.StartColumn = O.StartColumn;
            output.StartLine = O.StartLine + incr;

            return output;
        }

        private static Mono.Cecil.Cil.Document CopyDoc(Mono.Cecil.Cil.Document document)
        {
            if (document == null)
                return null;

            var output= new Mono.Cecil.Cil.Document(document.Url);

            output.Hash             = document.Hash;
            output.HashAlgorithm    = document.HashAlgorithm;
            output.Language         = document.Language;
            output.LanguageVendor   = document.LanguageVendor;
            output.Type             = document.Type;

            return output;
        }

        /// <summary>
        /// Represents an instruction in a method that must be processed by a refactoring operation.
        /// </summary>
        internal class TargetInstruction
        {
            /// <summary>
            /// A reference to the targeted instruction.
            /// </summary>
            public Mono.Cecil.Cil.Instruction instructionReference;

            /// <summary>
            /// The matching sequence point to that instruction.
            /// </summary>
            public Mono.Cecil.Cil.SequencePoint relevantSeqPoint = null;
        }

        /// <summary>
        /// Alter the code of a method, to add a call to another method at each control flow branch.
        /// </summary>
        /// <param name="method">The method where calls must be added</param>
        /// <param name="callTo">The method that the calls must invoke</param>
        static void ProcessMethod_AddJumpCalls(MethodDefinition method, MethodReference callTo)
        {
            // List of instructions before which a call must be inserted
            var targetInstructions = new List<TargetInstruction>();

            for (int idx = 0; idx < method.Body.Instructions.Count; idx++)
            {
                var i = method.Body.Instructions[idx];
                var op = i.OpCode;

                if (op.FlowControl == Mono.Cecil.Cil.FlowControl.Branch ||
                    op.FlowControl == Mono.Cecil.Cil.FlowControl.Cond_Branch)
                {
                    targetInstructions.Add(new TargetInstruction{
                        instructionReference= i,
                        relevantSeqPoint= null //CopySeqPoint(FindSeqPointAbove(i)), // According to some testing I did, this has no particular effect, so I comment it 
                    });
                }
            }

            // Once we have determined all instructions that alter the control flow, 
            // we can add a call to "callTo" before each one of them

            var processor = method.Body.GetILProcessor();
            
            foreach (var instHolder in targetInstructions)
            {
                var inst = instHolder.instructionReference;

                var newInstruction = processor.Create(Mono.Cecil.Cil.OpCodes.Call, callTo);
                //newInstruction.SequencePoint = instHolder.relevantSeqPoint; // 1.0.2
                processor.InsertBefore(inst, newInstruction);

                // If the control flow operand is an instruction, and that this instruction points to itself
                // then it will leave no chance to "callTo" being called at each iteration,
                // so we change the operand to point to the newInstruction making the call in this case
                if (inst.Operand is Mono.Cecil.Cil.Instruction)
                {
                    if (inst.Operand == inst)
                    {
                        inst.Operand = newInstruction;
                    }
                }
            }
        }
        #endregion

        #region Instance methods


        /// <summary>
        /// Determines if an assembly file can be safely prevented from being passed to RevertAssembly().
        /// The advantage of using this method before actually calling RevertAssembly() is that it opens the file in
        /// Read mode first, so this can prevent sharing violations that could had happen in RevertAssembly() whichs opens the file
        /// in ReadWrite.
        /// </summary>
        /// <param name="filename">The path to the assembly file to inspect</param>
        /// <returns>true if there is no need to call RevertAssembly() on the provided assembly</returns>
        internal static bool CanWeIgnoreThisAssemblyForRevert(string filename)
        { 
            if (Path.GetFileName(filename) == "Dezgo_PanicButton.dll")
                return true;

            using (var f = File.Open(filename, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                ModuleDefinition module = null;

                try
                {
                    module = ModuleDefinition.ReadModule(new MemoryStream(Utils.ReadAllBytes(f)));
                }
                catch (Exception e)
                {
                    return false;
                }

                // If the marker has been set, do the revert operation
                if (IsMarkerSet(module))
                {
                    return false;
                }
            }

            return true;
        }



        /// <summary>
        /// Reverts an assembly to its original unprocessed state.
        /// </summary>
        /// <param name="filename">the path to the assembly</param>
        /// <returns>true if the assembly has been reverted ; false if not (because it was not processed)</returns>
        internal static bool RevertAssembly(string filename)
        {
            if (Path.GetFileName(filename) == "Dezgo_PanicButton.dll")
                return false;

            // 1.1.2 : manage read-only attributes (especially useful for Perforce users)
            var attr = new AttrManager(filename);
            


            // Load the file
            // 1.0.4 : Relaxed a bit the sharing restrictions from None to Read
            using(var f = File.Open(filename, FileMode.Open, FileAccess.ReadWrite, FileShare.Read))
            {
                
                ModuleDefinition module = null;

                try
                {
                    // NOTE: no need for a resolver, we don't load any type
                    module = ModuleDefinition.ReadModule(new MemoryStream(Utils.ReadAllBytes(f)));
                }
                catch(BadImageFormatException e)
                {
                    Utils.LogWarning(Logging.User, "Cannot revert this assembly, because of a BadImageFormatException (maybe it's not a .NET DLL?) :\n=> {0}\n"+
                    "Exception thrown during reading of the assembly:\n{1}", filename, e);
                    attr.Close();
                    return false;
                }
                catch(Exception e)
                {
                    Utils.LogError(Logging.User, "Cannot revert this assembly:\n=> {0}\nException thrown during reading of the assembly:\n{1}", filename, e);
                    attr.Close();
                    return false;
                }

                // If the marker has been set, do the revert operation
                if(IsMarkerSet(module))
                {
                    // Get the original input
                    var originalData = ExtractResource(module, inputDataKey);

                    // Erase the processed data
                    f.Position = 0;
                    f.SetLength(0);

                    // Write the unprocessed data
                    f.Write(originalData, 0, originalData.Length);

                    // 1.0.2
                    var originalSymbols = ExtractResource(module, inputDataKey + "MDB");
                    if(originalSymbols != null)
                    {
                        try
                        {
                            using(var fSymbols = File.Open(filename + ".mdb", FileMode.Open, FileAccess.Write, FileShare.None))
                            {
                                fSymbols.Write(originalSymbols, 0, originalSymbols.Length);
                            }
                        }
                        catch(Exception e)
                        {
                            Utils.LogError(Logging.User, "Cannot revert original symbol file: {0}\nPlease ensure the file is not opened in any other program.\nException thrown while trying to write: {1}",
                                filename+".mdb", e);
                        }
                    }

                    attr.Close();
                    return true;
                }
                else
                {
                    attr.Close();
                    return false;
                }
            }

            
            
        }

        /// <summary>
        /// Process the provided assembly.
        /// </summary>
        /// <param name="filename">path to an assembly</param>
        /// <param name="wasProcessed">True if the target assembly has been processed ; false if not (can happen if it was already processed or if it's the Panic Button DLL)</param>
        /// <returns>the name definition of this assembly</returns>
        AssemblyNameDefinition ProcessAssembly(string filename, out bool wasProcessed)
        {
            wasProcessed = false;
            MakeAssemblyResolver();

            lock(_sync)
            {
                try
                {
                    return ProcessAssembly_Procedure(filename, out wasProcessed);
                }
                catch(System.BadImageFormatException e)
                {
                    var msg = "Cannot protect this DLL because the image format is bad, maybe it's not a .NET assembly?\n=> " + filename + "\n\n";
                    msg += string.Format("Internal exception thrown: {0}\n", e);

                    Utils.LogWarning(Logging.User, msg);
                }
                catch(Exception e)
                {
                    string helpfulText = "";

                    
                    if(IsSharingViolation(e))
                    {
                        helpfulText = TEXT_FILE_OPENED_IN_ANOTHER_PROGRAM;
                    }

                    var msg = "Cannot protect file. "+helpfulText+" => " + filename + "\n";
                    msg += string.Format("Internal exception thrown: {0}\n", e);

                    Utils.LogError(Logging.User, msg);
                }
            }

            return null;
        }

        /// <summary>
        /// Creates the Cecil assembly resolver object from the resolvingPaths
        /// </summary>
        private void MakeAssemblyResolver()
        {
            IAssemblyResolver r = this.cachedResolver;
            if (r == null)
            {
                var dar = new DefaultAssemblyResolver();
                foreach (var i in resolvingPaths)
                    dar.AddSearchDirectory(i);

                r = dar;
                this.cachedResolver = dar;
            }
        }


        /// <summary>
        /// WARNING: DO NOT USE YET.
        /// </summary>
        /// <param name="inputFilename"></param>
        /// <returns>true if the assembly is definitely processed ; false if it's not or if we are not sure (error)</returns>
        bool IsAssemblyProcessed_Safe(string inputFilename)
        {
            try
            {
                using (var f = File.Open(inputFilename, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var raw = Utils.ReadAllBytes(f);
                    byte[] rawSymbols = null;

                    var module = LoadModule(ref raw, ref rawSymbols);

                    if (IsMarkerSet(module))
                        return true;
                }
            }
            catch
            {
                
            }

            return false;
        }

        /// <summary>
        /// Processes the given assembly (not wrapped with try/catch, must only be called by the method ProcessAssembly() that handles exceptions !)
        /// </summary>
        /// <param name="inputFilename">a path to the assembly file</param>
        /// <param name="wasProcessed">True if the target assembly has been processed ; false if not (can happen if it was already processed or if it's the Panic Button DLL)</param>
        /// <returns>The name of the Assembly processed</returns>
        AssemblyNameDefinition ProcessAssembly_Procedure(string inputFilename, out bool wasProcessed)
        {
            wasProcessed = false;

            // If this assembly is Panic Button itself: skip.
            if(Path.GetFileName(inputFilename) == "Dezgo_PanicButton.dll")
            {
                return null;
            }

            // 1.1.2 : manage read-only attributes (especially useful for Perforce users)
            var attr = new AttrManager(inputFilename);

            using (var inputFile = File.Open(inputFilename, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) 
            { 
                // Load bytes...
                byte[] rawData = Utils.ReadAllBytes(inputFile);
                byte[] rawSymbols = null;

                // 1.0.2 - Try to load symbols file
                var symbolPath = inputFilename + ".mdb";
                try
                {
                    //Utils.LogWarning(Logging.User, "Try to load symbols at : {0}", symbolPath); 

                    using (var inputSymbolFile = File.Open(symbolPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        rawSymbols= Utils.ReadAllBytes(inputSymbolFile);

                        //Utils.LogWarning(Logging.User, "Read {0} bytes of symbols for {1}", rawSymbols.Length, inputFilename); 
                    }
                }
                catch(System.IO.FileNotFoundException)
                {
                    // If there is no symbol file, then there is not much we can do to load it
                }
                catch(Exception e) 
                {
                    Utils.LogError(Logging.User, "Error while reading symbols file: {0}\nException thrown: {1}", symbolPath , e); 
                }

                // Then load the ModuleDefinition...

                // the ref make sure the local variable above is corrected in case we read the input
                // from a resource (in case of a force recompile)
                ModuleDefinition module =  LoadModule(ref rawData, ref rawSymbols);
                AssemblyNameDefinition assemblyName = module.Assembly.Name;
                string outputFilePath = inputFilename;

                
                

                // If the marker has been set, then it's already processed
                if (IsMarkerSet(module))
                {
                    Utils.LogWarning(Logging.Dev, "Skip already processed : {0}", inputFilename);
                    attr.Close();
                    return assemblyName; 
                }

                // Alter the code
                PatchAssembly(module, rawData, rawSymbols);

                // Then write the assembly back
                inputFile.Position = 0;
                inputFile.SetLength(0);
                wasProcessed = true;
                module.Write(inputFile, new WriterParameters { WriteSymbols = false });
                
                // 1.0.2 - workaround: writing symbols directly to a Stream is not implemented in Cecil, we must pass through an intermediary file (source: MdbWriterProvider.GetSymbolWriter(ModuleDefinition, Stream) throws a NotImplementedException)
                if(module.HasSymbols)
                {
                    // OPTIMIZATION: We could avoid calling module.Write twice

                    var tempSymbolDll = Utils.MakePath("Library", "panicbutton_temp_assembly.dll");

                    module.Write(tempSymbolDll, new WriterParameters { WriteSymbols= true });

                    // Delete the useless DLL
                    File.Delete(tempSymbolDll);

                    // Move the symbol DLL to location
                    var attr2 = new AttrManager(inputFilename + ".mdb"); // 1.1.2

                    File.Delete(inputFilename + ".mdb");
                    File.Move(tempSymbolDll + ".mdb", inputFilename+".mdb");

                    attr2.Close(); // 1.1.2
                }

                Utils.Log(Logging.Dev, "Processed assembly: {0}\nto: {1}", inputFilename, outputFilePath);
                attr.Close();
                return assemblyName;
            }
        }

        /// <summary>
        /// Load a module from the raw bytecode.
        /// </summary>
        /// <param name="rawData">an assembly bytecode</param>
        /// <param name="rawSymbols">the symbol file contents for the given assembly or null if none are available</param>
        /// <returns></returns>
        private ModuleDefinition LoadModule(ref byte[] rawData, ref byte[] rawSymbols)
        {
            ModuleDefinition module = null;
            var ms = new MemoryStream(rawData);

            var readParams = new ReaderParameters { AssemblyResolver = this.cachedResolver, ReadSymbols = true };
            if(rawSymbols != null)
            {
                readParams.SymbolStream = new MemoryStream(rawSymbols);
            }

            try
            {
                module = ModuleDefinition.ReadModule(ms, readParams);
            }
            catch 
            {
                readParams.ReadSymbols = false;
                readParams.SymbolStream = null;
                ms.Position = 0;
                module = ModuleDefinition.ReadModule(ms, readParams);
            }

            if(IsMarkerSet(module))
            {
                if(forceRecompileEverything)
                {
                    Utils.LogError(Logging.Dev, "Extract the original input from {0}", module.Assembly.Name);
                    rawData = ExtractResource(module, inputDataKey);
                    
                    var newSymbols = ExtractResource(module, inputDataKey + "MDB"); // 1.0.2 : extract raw symbols

                    if(newSymbols != null)
                        rawSymbols = newSymbols;
                    
                    return LoadModule(ref rawData, ref rawSymbols);
                }
            }
            
            return module;
        }

        /// <summary>
        /// Patch the assembly by adding instrumentation code, and the input bytecode as an embedded resource.
        /// </summary>
        /// <param name="module">the input assembly module</param>
        /// <param name="input">the original input bytecode from which the assembly was loaded</param>
        private void PatchAssembly(ModuleDefinition module, byte[] input, byte[] symbolsInput)
        {
            // Add the whole input data backed up inside the processed assembly
            module.Resources.Add(new EmbeddedResource(inputDataKey, ManifestResourceAttributes.Public, input));
            
            // 1.0.2 : Store the symbols if we have them
            if(symbolsInput != null)
                module.Resources.Add(new EmbeddedResource(inputDataKey + "MDB", ManifestResourceAttributes.Public, symbolsInput));

            // Mark the assembly as processed
            var marker = new EmbeddedResource(markerKey, ManifestResourceAttributes.Public, Dezgo.Panic.PanicButton_Version.AsByteArray); // 1.0.2: put the version instead of an empty array, so that we can later identify from which version a specific assembly was processed
            module.Resources.Add(marker);

            // Import the instrumentation method
            MethodReference Probe = module.Import(typeof(RuntimeSystem).GetMethod("Probe"));
            if (Probe == null)
                throw new InvalidOperationException("Couldn't find the method reference to Probe");

            // Import the triggering field
            FieldReference ExpiredField = module.Import( typeof(RuntimeSystem).GetField("expired") );
            if (ExpiredField == null)
                throw new InvalidOperationException("Couldn't find the field reference to 'expired'");

            MethodReference DoExpiredMethod = module.Import(typeof(RuntimeSystem).GetMethod("DoExpired"));
            if (DoExpiredMethod == null)
                throw new InvalidOperationException("Couldn't find the method reference to DoExpired");

            // Loop through each type
            foreach (TypeDefinition type in module.GetTypes()) 
            {
                // it calls .GetTypes() instead of .Types because it processes nested types

                // Loop through each method
                foreach (var m in type.Methods)
                {
                    if (m.HasBody)
                    {
                        // 1.0.5: Transforms short-form opcodes to long-form opcodes
                        // Doing this prevents short branch offsets from overflowing
                        /*m.Body.SimplifyMacros();

                        ProcessMethod_AddCallBeginning(m, Probe);
                        ProcessMethod_AddJumpCalls(m, Probe);

                        // 1.0.5: Transforms long-form opcodes to short-form IF possible
                        m.Body.OptimizeMacros();*/

                        RefactoringUnits.ProcessMethod_MAIN(m, ExpiredField, DoExpiredMethod);
                    }
                }
            }

            
            // Post-processing steps
            foreach (var p in postProcessing)
            {
                p(module);
            }
        }


        /// <summary>
        /// Get the byte data of the resource "key" in the given assembly.
        /// </summary>
        /// <param name="module">The module in which to fetch the resource</param>
        /// <param name="resourceKey">The key of the resource to fetch</param>
        /// <returns></returns>
        private static byte[] ExtractResource(ModuleDefinition module, string resourceKey)
        {
            foreach(var res in module.Resources)
            {
                if(res.Name == resourceKey)
                {
                    return ((EmbeddedResource)res).GetResourceData();
                }
            }

            return null;
        }


        /// <summary>
        /// Checks if the provided assembly has the "processed" marker set.
        /// </summary>
        /// <param name="module"></param>
        /// <returns>false if no marker ; true if the marker is set</returns>
        private static bool IsMarkerSet(ModuleDefinition module)
        {
            foreach (var res in module.Resources)
            {
                if (res.Name == markerKey || res.Name == altMarkerKey)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion


        /// <summary>
        /// Checks if the ScriptAssemblies folder has been processed (presence of a token file)
        /// </summary>
        /// <returns>true if the token file could be found</returns>
        internal static bool IsScriptAssembliesProcessed()
        {
            return System.IO.File.Exists(PROCESSED_TOKEN_FILEPATH);
        }

        /// <summary>
        /// Marks the ScriptAssemblies folder as processed (emits a token file)
        /// </summary>
        internal static void MarkScriptAssembliesAsProcessed()
        {
            using (var tokenF = System.IO.File.Open(PROCESSED_TOKEN_FILEPATH, FileMode.Create, FileAccess.Write))
            {
                tokenF.Flush();   
            }
        }
    }
}
