﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Dezgo.Panic
{
    /// <summary>
    /// Manage the attributes of a file which is a target for refactory.
    /// Handle changing the read-only and resetting it in particular
    /// </summary>
    class AttrManager
    {

        readonly string filename;
        readonly FileAttributes fileAttr;

        bool wasChanged = false;

        bool isReadOnly
        {
            get { return (fileAttr & FileAttributes.ReadOnly) != 0;  }
        }        
               
        
        public AttrManager(string filename)
        {
            this.filename = filename;
            this.fileAttr = File.GetAttributes(filename);

            Open();
        } 


        /// <summary>
        /// this method is private because it is called automatically in the constructor
        /// to simplify the client side code
        /// </summary>
        private void Open()
        {
            if (isReadOnly)
            {
                // and the relevant setting is activated
                if (Dezgo.Panic.EditorExt.EditorSystem.Settings.autoChangeReadOnlyAttribute)
                {
                    // Remove read only temporarily
                    File.SetAttributes(filename, fileAttr & ~FileAttributes.ReadOnly);
                    wasChanged = true;
                }
            }
        }

        public void Close()
        {
            if (wasChanged)
            {
                // If it was read only before, we reset the attributes to the originals
                File.SetAttributes(filename, fileAttr);
            }
        }

    }
}
