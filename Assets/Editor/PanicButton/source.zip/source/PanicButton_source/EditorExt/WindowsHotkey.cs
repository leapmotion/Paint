﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dezgo.Sys
{
    /// <summary>
    /// Implementation of IHotKey for Windows
    /// </summary>
    internal class WindowsHotkey : IHotKey
    {
        /// <summary>
        /// Associates hotkey ids to their registered callbacks
        /// </summary>
        Dictionary<int, Action> hotkeyCallbacks = new Dictionary<int, Action>();
   
        /// <summary>
        /// The collection of available modifiers. The dictionnary's key is the human-readable name, and the value is the system's code.
        /// </summary>
        static Dictionary<string, uint> modifiers_collection = new Dictionary<string, uint>();

        static WindowsHotkey()
        {
            modifiers_collection["Ctrl"] = User32.MOD_CONTROL;
            modifiers_collection["Alt"] = User32.MOD_ALT;
            modifiers_collection["Win"] = User32.MOD_WIN;
            modifiers_collection["Shift"] = User32.MOD_SHIFT;
        }

        
         
        public string Register(int id, uint modifiers, uint keycode, Action callback)
        {
            // We associate the callback to the id, so that we can later know which delegate to call when we receive a message
            hotkeyCallbacks[id] = callback;

            // Ensure the key is unregistered before attempting to re-register it again
            User32.UnregisterHotKey(System.IntPtr.Zero, id);
            bool success = User32.RegisterHotKey(System.IntPtr.Zero, id, modifiers, keycode);

            if (!success)
            {
                var errorcode=  System.Runtime.InteropServices.Marshal.GetLastWin32Error().ToString();
                return "Couldn't bind the specified Panic hotkey.\nPlease try a different key combination in \"Edit > Panic Button Settings\"" + "\nWindows error code: " + errorcode;
            }

            return null;
        }

        public bool WaitNext()
        {
            var msg = new User32.MSG();
            var hwnd = new IntPtr(0);

            // Poll the Win32 message queue
            if( User32.PeekMessage(out msg, hwnd, 0, 0, User32.PM_REMOVE) )
            {
                // If the message type is about a hotkey that was just fired
                if (msg.message == User32.WM_HOTKEY)
                {
                    // Retrieve the id of the hotkey
                    int id = msg.wParam.ToInt32();

                    // Then check if we have a registered callback matching that ID
                    if (hotkeyCallbacks.ContainsKey(id))
                    {
                        // and call it!
                        hotkeyCallbacks[id]();
                        return true;
                    }
                }
            }

            return true;
        }


        public static IDictionary<string, uint> GetModifiers
        {
            get { return modifiers_collection; }
        }

        public IDictionary<string, uint> Modifiers
        {
            get { return modifiers_collection; }
        }

        public IDictionary<string, uint> Keycodes
        {
            get { throw new NotImplementedException(); }
        }
    }
}
