﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Threading;

namespace Dezgo.Sys
{
    /// <summary>
    /// Implementation of IHotKey using an external helper process.
    /// 
    /// The hotkey to register is specified as two arguments on the command line : 1) a modifiers bitfield ; 2) a keycode 
    /// Both codes should be in the current system-specific format.
    /// 
    /// The helper program communicates on stdout.
    /// The first byte is either "y" if registering was succesful or "n" if it failed (no further bytes will be sent in this case and the program should close).
    /// All subsequent bytes are either "1" when a hotkey press was detected, or "0" if none was detected (note: this is ASCII "1" and "0", not byte value).
    /// 
    /// Sending "0" once in a while ensures that the helper process will receive SIGPIPE when its parent is no longer reading from the pipe.
    ///
    /// This implementation is used for OSX where the hotkeys are implemented as an external program, written in C and interfacing with the Carbon API directly.
    /// </summary>
    internal class ProcessHotKey : IHotKey
    {
        /// <summary>
        /// Where to find the helper program to get hotkey data
        /// </summary>
        readonly string executablePath;

        /// <summary>
        /// The last launched process.
        /// </summary>
        Process pr = null;

        /// <summary>
        /// The standard output of the last launched process.
        /// </summary>
        Stream stdout = null;

        
        /// <summary>
        /// The delegate to call when a hotkey is detected
        /// </summary>
        Action callback = null;

        /// <summary>
        /// Hotkey press notification switch.
        /// The Stdout Reader Thread sets it to true when the helper process detects a hotkey press
        /// And the IHotKey.WaitNext consumer detects it, calls the callback and resets it 
        /// </summary>
        volatile bool trigger = false;

        /// <summary>
        /// This ensures .ReleaseResources is processed atomically
        /// </summary>
        object _instanceMutex = new object();



        /// <summary>
        /// System codes for modifiers on Mac OS X
        /// </summary>
        static readonly Dictionary<string, uint> macModifiers = new Dictionary<string, uint>();

        static ProcessHotKey()
        {
            macModifiers["Cmd"] = 1 << 8;
            macModifiers["Ctrl"] = 1 << 12;
            macModifiers["Alt"] = 1 << 11;
            macModifiers["Shift"] = 1 << 9;
        }


        


        public ProcessHotKey(string executablePath)
        {
            this.executablePath = executablePath;


            // Fix: 1.0.1: ensure the file has execution rights
            var pr = new Process();
            pr.StartInfo.FileName = "chmod";
            //pr.StartInfo.Arguments = "+x Assets/Editor/PanicButton/MacHotKeys";
            pr.StartInfo.Arguments   = "+x "+  EscapeCmdArg(executablePath); 
            pr.Start();
            pr.WaitForExit(10000);
            
            // Ensures that resources are released during the AppDomain Unload.
            // We use this method, because there was strange issues when using a destructor.
            System.AppDomain.CurrentDomain.DomainUnload += CurrentDomain_DomainUnload;
        }

        /// <summary>
        /// Simple command line argument escaping routine (wraps in ", and replace any backslashes with slashes)
        /// </summary>
        /// <param name="arg"></param>
        /// <returns></returns>
        private string EscapeCmdArg(string arg)
        {
            string output = "\"";

            output += arg.Replace("\\", "/");
            output += "\"";

            return output;
        }

        /// <summary>
        /// Releases resources during AppDomain unloading
        /// </summary>
        void CurrentDomain_DomainUnload(object sender, EventArgs eventArgs)
        {
            try
            {
                ReleaseResources();
            }
            catch(Exception e)
            {
                Dezgo.Panic.EditorExt.FatalErrorWindow.SubmitAnAlert("An exception occured during unloading of the process hotkey : " + e.GetType().ToString(), e.ToString(), toFile: true);
            }
        }


        /// <summary>
        /// Starts the helper process.
        /// </summary>
        /// <param name="modifiers">The modifiers to use when registering the hotkey</param>
        /// <param name="keycode">The main keycode to use when registering the hotkey</param>
        /// <returns>null on success or an error string</returns>
        string StartProcess(UInt32 modifiers, UInt32 keycode)
        {
            lock (_instanceMutex)
            {
                /* RELEASE PREVIOUS RESOURCES */
                ReleaseResources();
             
                /* START NEW PROCESS */
                pr = new Process();
                pr.StartInfo.FileName = executablePath;
                pr.StartInfo.UseShellExecute = false;
                pr.StartInfo.RedirectStandardOutput = true;
                pr.StartInfo.Arguments = string.Format("{0} {1}", modifiers, keycode);
                pr.Start(); 
                stdout = pr.StandardOutput.BaseStream;

                var status = (char)stdout.ReadByte(); 
                if (status != 'y')
                {
                    // read error code and report it
                    var errorCode = pr.StandardOutput.ReadToEnd();

                    // normally the process should end itself, but anyway, we try to kill it just to be sure
                    try
                    {
                        pr.Kill();
                    }
                    catch { }

                    return "The external hotkey helper process couldn't initialize properly.\nProcess error code: " + errorCode.ToString();
                }

                // Start the reader thread
                var th = new Thread(() => ReaderThreadProc(pr));
                th.Start();
            }

            return null;
        }

        /// <summary>
        /// Release resources associated to a previous helper program instance
        /// </summary>
        private void ReleaseResources()
        {
            lock (_instanceMutex)
            {
                int code = int.MinValue;

                // End the process
                if (pr != null)
                {
                    if (!pr.HasExited)
                    {
                        try
                        {
                            pr.Kill();
                        }
                        catch (InvalidOperationException)
                        {
                            // Oops, you exited in the meantime, nevermind :p
                        }
                    }

                    try
                    {
                        pr.WaitForExit(15 * 1000);
                    }
                    catch
                    {

                    }

                    if (pr.HasExited)
                    {
                        code = pr.ExitCode;
                    }

                    try
                    {
                        pr.Dispose();
                    }
                    catch { }
                }

                // The associated thread will end automatically when the process exits

                // Close stdout
                if (stdout != null)
                {
                    try
                    {
                        stdout.Close();
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// The thread procedure that reads the stdout stream and interprets it.
        /// </summary>
        /// <param name="myPr">The process that we are reading from</param>
        void ReaderThreadProc(Process myPr)
        {
            try
            {
                Stream myStdout = myPr.StandardOutput.BaseStream;

                while (true)
                {
                    var incomingByte = myStdout.ReadByte();

                    // Automatically finish the thread if the process exited
                    if (incomingByte == -1 || myPr.HasExited)
                    {
                        break;
                    }
                    
                    // When a hotkey press is detected, set the trigger on
                    if ((char)incomingByte == '1')
                        trigger = true;
                }

                myStdout.Close();
            
            }
            catch(Exception e)
            {
                Dezgo.Panic.EditorExt.FatalErrorWindow.SubmitAnAlert("An exception occured in the thread reading the hotkey helper process output.", e.ToString());
            }
        }


        /// <summary>
        /// Registers the hotkey.
        /// WARNING: this implementation only supports one hotkey at a time. The "id" parameter is simply ignored.
        /// </summary>
        string IHotKey.Register(int id, uint modifiers, uint keycode, Action callback)
        {
            this.callback = callback;

            string errorcode = StartProcess(modifiers, keycode);
            
            return errorcode; 
        }

        bool IHotKey.WaitNext()
        {
            // We just check if the "trigger" switch is on,
            // if so, we reset it and call the callback.

            if(trigger)
            {
                trigger = false;

                if (callback != null)
                    callback();
            }

            return true;
        }

        IDictionary<string, uint> IHotKey.Modifiers
        {
            get
            {
                return macModifiers;
            }
        }

        internal static IDictionary<string, uint> MacModifiers
        {
            get
            {
                return macModifiers;
            }
        }
    }
}
