﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


namespace Dezgo.Sys
{
    /// <summary>
    /// Provides a way to translate keycodes between agnostic-keycodes (UnityEngine.KeyCode for keys and PanicSettings.KeyModifiers for modifiers)
    /// and system-specific codes.
    /// </summary>
    abstract class KeycodeTransposition
    {
        /// <summary>
        /// Association of agnostic KeyCode to system-specific codes
        /// </summary>
        protected Dictionary<KeyCode, int> keyTable;

        /// <summary>
        /// Association of system-specific codes to KeyCode
        /// </summary>
        protected Dictionary<int, KeyCode> keyTable_i;

        /// <summary>
        /// Association of agnostic KeyModifiers to system-specific modifiers codes
        /// </summary>
        protected Dictionary<PanicSettings.KeyModifiers, uint> modifiersTable;

        /// <summary>
        /// Association of system-specific modifiers codes to KeyModifiers
        /// </summary>
        protected Dictionary<uint, PanicSettings.KeyModifiers> modifiersTable_i;


        /// <summary>
        /// The system-specific implementation
        /// </summary>
        static KeycodeTransposition sysInstance = null;


        static KeycodeTransposition()
        {
            // Instantiates the correct system-specific implementation that will fill all the tables 
            switch(Application.platform)
            {
                case RuntimePlatform.WindowsEditor:
                    sysInstance = new KeyTransposition_Win32();
                    break;

                case RuntimePlatform.OSXEditor:
                    sysInstance = new KeyTransposition_OSX();
                    break;

                default:
                    Check();
                    break;
            }

            // Compute the inverted tables automatically
            sysInstance.keyTable_i = sysInstance.keyTable.ToDictionary(kp => kp.Value, kp => kp.Key);
            sysInstance.modifiersTable_i = sysInstance.modifiersTable.ToDictionary(kp => kp.Value, kp => kp.Key);
        }

        /// <summary>
        /// Check that the current system instance is loaded, if not, throw an exception (because this means it is not supported)
        /// </summary>
        static void Check()
        {
            if (sysInstance == null)
                throw new NotSupportedException("There is no keycode mapping for the current system");
        }

        /// <summary>
        /// Converts the specified system-specific keycode to an agnostic UnityEngine.KeyCode
        /// </summary>
        public static KeyCode? TransposeToUnity(uint systemKeycode)
        {
            Check();

            if (!sysInstance.keyTable_i.ContainsKey((int)systemKeycode))
                return null;

            return sysInstance.keyTable_i[(int)systemKeycode];
        }

        /// <summary>
        /// Converts the specified agnostic UnityEngine.KeyCode to a system-specific keycode
        /// </summary>
        public static uint? TransposeToSystem(KeyCode unityKeycode)
        {
            Check();

            if (!sysInstance.keyTable.ContainsKey(unityKeycode))
                return null;

            return (uint)sysInstance.keyTable[unityKeycode];
        }

        /// <summary>
        /// Returns the friendly name of the current's system "system key" ("Windows" on Windows and "Cmd" on OSX)
        /// </summary>
        internal static string GetFriendlySystemKeyName()
        {
            string str = "System";

            switch (Application.platform)
            {
                case RuntimePlatform.WindowsEditor:
                    str = "Windows";
                    break;

                case RuntimePlatform.OSXEditor:
                    str = "Cmd";
                    break;

                default:
                    break;
            }

            return str;
        }
    

        /// <summary>
        /// Converts the specified system-specific modifiers code to an agnostic PanicSettings.KeyModifiers code
        /// </summary>
        public static PanicSettings.KeyModifiers? TransposeToUnity_Modifier(uint systemKeycode)
        {
            Check();

            PanicSettings.KeyModifiers output = 0;

            foreach(var k in sysInstance.modifiersTable_i)
            {
                if((systemKeycode & k.Key) != 0)
                    output|= k.Value;
            }

            return output;
        }

        /// <summary>
        /// Converts the specified agnostic PanicSettings.KeyModifiers code to a system-specific modifiers code
        /// </summary>
        public static uint? TransposeToSystem_Modifiers(PanicSettings.KeyModifiers unityKeycode)
        {
            Check();

            uint output = 0;

            if ((unityKeycode & PanicSettings.KeyModifiers.Alt) != 0)
                output|= sysInstance.modifiersTable[PanicSettings.KeyModifiers.Alt];

            if ((unityKeycode & PanicSettings.KeyModifiers.Ctrl) != 0)
                output |= sysInstance.modifiersTable[PanicSettings.KeyModifiers.Ctrl];

            if ((unityKeycode & PanicSettings.KeyModifiers.Shift) != 0)
                output |= sysInstance.modifiersTable[PanicSettings.KeyModifiers.Shift];

            if ((unityKeycode & PanicSettings.KeyModifiers.System) != 0)
                output |= sysInstance.modifiersTable[PanicSettings.KeyModifiers.System];

            return output;
        }

        /// <summary>
        /// Returns a human-readable text representation of the specified modifiers bitfield
        /// </summary>
        /// <param name="modifiers_nullable">A bitfield of modifiers</param>
        /// <returns></returns>
        static string PrettyPrintModifiers(PanicSettings.KeyModifiers? modifiers_nullable)
        {
            if (!modifiers_nullable.HasValue)
                return "[?]";

            var modifiers = modifiers_nullable.Value;

            var selectedModList = new List<string>(4);

            // We check each one by one and add them in the list of active modifiers
            if ((modifiers & PanicSettings.KeyModifiers.Ctrl) != 0) selectedModList.Add("Ctrl");
            if ((modifiers & PanicSettings.KeyModifiers.Alt) != 0) selectedModList.Add("Alt");
            if ((modifiers & PanicSettings.KeyModifiers.Shift) != 0) selectedModList.Add("Shift");
            if ((modifiers & PanicSettings.KeyModifiers.System) != 0) selectedModList.Add(KeycodeTransposition.GetFriendlySystemKeyName());

            // And merge them in a string separated by "+"
            return string.Join("+", selectedModList.ToArray());
        }

        /// <summary>
        /// Returns a human-readable text representation of the specified hotkey, composed of a modifiers bitfield and a keycode (in system-specific codes)
        /// </summary>
        internal static string PrettyPrintHotkey(uint modifiers, uint keycode)
        {
            var u_modifiers = KeycodeTransposition.TransposeToUnity_Modifier(modifiers);
            var u_keycode = KeycodeTransposition.TransposeToUnity(keycode);

            return PrettyPrintHotkey(u_modifiers, u_keycode);
        }

        /// <summary>
        /// Returns a human-readable text representation of the specified hotkey, composed of a modifiers bitfield and a keycode
        /// </summary>
        internal static string PrettyPrintHotkey(PanicSettings.KeyModifiers? modifiers, KeyCode? keycode)
        {
            string modStr = KeycodeTransposition.PrettyPrintModifiers( modifiers );

            if (modStr != "")
                modStr += "+";

            return modStr + (keycode.HasValue ? keycode.Value.ToString() : "[?]");
        }
    }
}
