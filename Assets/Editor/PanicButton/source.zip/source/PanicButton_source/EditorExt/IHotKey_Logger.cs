﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dezgo.Sys
{
    /// <summary>
    /// Decorates another IHotKey class with logging to the console when a hotkey is registered.
    /// </summary>
    class HotKey_Logger : IHotKey
    {
        readonly IHotKey parent;


        public HotKey_Logger(IHotKey parent)
        {
            this.parent = parent;
        }


        public string Register(int id, uint modifiers, uint keycode, Action callback)
        {
            // We display a user-friendly text representation of the hotkey
            //Dezgo.Panic.Utils.Log(Dezgo.Panic.Logging.User, "Register hotkey: {0}", KeycodeTransposition.PrettyPrintHotkey(modifiers, keycode));

 
            string result = null, details = "";

            // After that, we can call the underlying implementation's Register() method
            // but we also catch exceptions to display them
            try
            {
                result = parent.Register(id, modifiers, keycode, callback);
            }
            catch(Exception e)
            {
                result = "An exception occured while attempting to register the Panic hotkey: "+ e.GetType().ToString();
                details = e.ToString();
            }

            // A non-null value means an error, so we should display it big
            if(result != null)
            {
                Dezgo.Panic.EditorExt.FatalErrorWindow.SubmitAnAlert(result, details);
            }

            return result;
        }

        public bool WaitNext()
        {
            return parent.WaitNext();
        }

        public IDictionary<string, uint> Modifiers
        {
            get { return parent.Modifiers; }
        }
    }
}
