﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


namespace Dezgo.Sys
{
    /// <summary>
    /// Implementation of the keycode transposition tables for Windows
    /// </summary>
    class KeyTransposition_Win32 : KeycodeTransposition
    {
        public KeyTransposition_Win32()
        {
            keyTable = new Dictionary<UnityEngine.KeyCode, int>();
            modifiersTable = new Dictionary<PanicSettings.KeyModifiers, uint>();

            for (int i = 0; i < 26; i++ )
                keyTable[KeyCode.A + i] = 0x41 + i;

            for (int i = 0; i < 10; i++ )
            {
                keyTable[KeyCode.Alpha0 +i]  = 0x30 + i;
                keyTable[KeyCode.Keypad0+i] = 0x60 + i;
            }


            for (int i = 0; i < 15; i++ )
            {
                keyTable[KeyCode.F1 + i] = 0x70 + i;
            }

            keyTable[KeyCode.Escape] = 0x1B;
            keyTable[KeyCode.ScrollLock]= 0x91;
            keyTable[KeyCode.Pause]= 0x13;

            keyTable[KeyCode.Backspace]= 0x08;
            keyTable[KeyCode.Tab] = 0x09;
            keyTable[KeyCode.Space]= 0x20;

            keyTable[KeyCode.Insert]= 0x2d;
            keyTable[KeyCode.Delete]= 0x2e;
            keyTable[KeyCode.Home]= 0x24;
            keyTable[KeyCode.End]= 0x23;
            keyTable[KeyCode.PageUp]= 0x21;
            keyTable[KeyCode.PageDown] = 0x22;

            keyTable[KeyCode.UpArrow]    = 0x26 ;
            keyTable[KeyCode.DownArrow]  = 0x28 ;
            keyTable[KeyCode.LeftArrow]  = 0x25 ;
            keyTable[KeyCode.RightArrow] = 0x27 ;

            keyTable[KeyCode.Numlock] = 0x90;
            keyTable[KeyCode.KeypadDivide]= 0x6f;
            keyTable[KeyCode.KeypadMultiply]= 0x6a;
            keyTable[KeyCode.KeypadMinus]= 0x6d;
            keyTable[KeyCode.KeypadPlus]= 0x6b;

            modifiersTable[PanicSettings.KeyModifiers.Alt] = User32.MOD_ALT;
            modifiersTable[PanicSettings.KeyModifiers.Ctrl] = User32.MOD_CONTROL;
            modifiersTable[PanicSettings.KeyModifiers.Shift] = User32.MOD_SHIFT;
            modifiersTable[PanicSettings.KeyModifiers.System] = User32.MOD_WIN;
        }
    }
}
