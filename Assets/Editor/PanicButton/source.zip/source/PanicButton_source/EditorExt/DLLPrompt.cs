﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using UnityEditor;

namespace Dezgo.Panic.EditorExt
{
	[InitializeOnLoad]
    static class DLLPrompt
    {
        private static readonly string textDllFound = "Panic Button has detected DLL files in your Assets/ folder.";
        private static readonly string textDllMaybe = "You may be using scripts in DLL files.";
		
        static DLLPrompt()
        {
            TriggerPrompt();
        }

		/// <summary>
		/// Checks if DLL files were detected.
        /// If possible, use the Refactory cache file to avoid rescanning the Assets/ folder
        /// 
		/// </summary>
		/// <returns>0 : no DLL ; 1 : DLL found ; negative: maybe (unable to check because an error prevented it)</returns>
        static int IsThereDLL()
        {

            try
            {
                try
                {
                    if (File.Exists(Refactory.isDllCacheFilePath))
                    {
                        using (var f = File.Open(Refactory.isDllCacheFilePath, FileMode.Open, FileAccess.Read))
                        {
                            Utils.Log(Logging.Dev, "IsThereDLL: found in file");
                            var isDLL = f.ReadByte() == 1;

                            var pidBytes = new byte[4];
                            f.Read(pidBytes, 0, pidBytes.Length);
                            int pid = BitConverter.ToInt32(pidBytes, 0);

                            if (pid == Process.GetCurrentProcess().Id)
                            {
                                Utils.Log(Logging.Dev, "pid: ok");
                                return isDLL ? 1 : 0;
                            }
                            else
                            {
                                Utils.Log(Logging.Dev, "pid: wrong");
                            }
                        }
                    }
                }
                catch
                {
                    // If there is any exception with the cache file, we just proceed to try a FindDLL scan
                }


                // No cache, so FindDLL scan
                Utils.Log(Logging.Dev, "IsThereDLL: scan");
                bool foundSomething = false;
                foreach (var i in Refactory.FindDLLs("Assets"))
                {
                    if (Path.GetFileName(i) == "Dezgo_PanicButton.dll" || Path.GetFileName(i) == "Dezgo_PanicButton_asset.dll")
                        continue;

                    Utils.Log(Logging.Dev, "IsThereDLL: Found: {0}", i);

                    foundSomething = true;
                    break;
                }

                return foundSomething ? 1 : 0;
            }
			catch
            {
				// There should be no exception, but if for a random reason there is
				// this means we are unable to check if there really is DLL
				// so the answer then is : 
				//
				// MAYBE

                return -1;
            }
        }


		static void TriggerPrompt()
        {
           
            var s = EditorSystem.Settings;

            if (!s.displayedDLLPrompt)
            {
				var dllStatus = IsThereDLL();
                Utils.Log(Logging.Dev, "TriggerPrompt: {0}", dllStatus);

                if (dllStatus != 0)
                {
                    if (true)
                    {
                        if (EditorUtility.DisplayDialog("Panic Button - DLL Protection",
                            ((dllStatus == 1) ? textDllFound : textDllMaybe) + "\n\n" +
                            "In order to protect these from freezes, Panic Button needs to patch DLL files.\n" +
                            "The patch will be automatically removed in your player builds or if you later decide to disable this functionnality in \"Edit > Panic Button Settings\".\n\n" +
                            "Do you want to enable automatic DLL protection ?",
                            "Yes", "No"))
                        {
                                s.protectAllDLLs = true;
                                
                                //EditorSystem.forceReloadRequested = true; 
                                EditorSystem.displayDllOkay = true;
                        }
                    }

                    s.displayedDLLPrompt = true;
                    PanicSettings.Save(s);
                    System.Threading.Interlocked.Increment(ref EditorSystem.workaround_requests);
                    
                }
            }
        
        }




    }
}
