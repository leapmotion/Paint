﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dezgo.Sys
{
    /// <summary>
    /// Provides a system-agnostic interface to accessing global hotkeys functionnality
    /// </summary>
    interface IHotKey
    {
        /// <summary>
        /// Registers a hotkey notification.
        /// </summary>
        /// <param name="id">The identifier for this particular hotkey instance</param>
        /// <param name="modifiers">A bitflag of the modifiers to press</param>
        /// <param name="keycode">The keycode to press</param>
        /// <param name="callback">The function to call when the hotkey is activated</param>
        /// <returns>null if the registration was successful, an error string otherwise</returns>
        string Register(int id, uint modifiers, uint keycode, Action callback);
        
        /// <summary>
        /// Blocks execution of the current thread until a hotkey is pressed.
        /// When a hotkey is pressed, the provided Action callback will automatically be called.
        /// If you want to continue responding to hotkeys, you must then call this method again.
        /// </summary>
        /// <returns>true if the event loop continues ; false if you shall stop calling (eg. the application is exiting)</returns>
        bool WaitNext();

        /// <summary>
        /// Returns a list of implementation-specific modifiers.
        /// </summary>
        IDictionary<string, uint> Modifiers {get;}
    }



}
