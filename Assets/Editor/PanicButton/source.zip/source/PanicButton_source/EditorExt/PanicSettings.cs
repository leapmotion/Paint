﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

/// <summary>
/// The user-configurable settings of Panic Button
/// </summary>
[System.Serializable]
internal class PanicSettings 
{
    /// <summary>
    /// The system-agnostic modifiers codes. This way we can store modifiers independently of the system where Panic Button is currently executing, 
    /// so moving the settings file to another OS won't create problems. 
    /// </summary>
    [System.Flags]
    [System.Serializable]
    public enum KeyModifiers : int
    {
        Ctrl = 1 << 0,
        Alt = 1 << 1,
        Shift = 1 << 2,
        System = 1 << 3
    };



    /// <summary>
    /// The path of the file where settings are stored.
    /// </summary>
    static string settingsPath
    {
        get
        {
            return Dezgo.Panic.Utils.MakePath(Dezgo.Panic.Utils.AssemblyDirectory, "PanicButton_settings");
        }
    }
    
    
    /// <summary>
    /// Is the auto-abort enabled ?
    /// </summary>
    public bool enableAutostop = true;
    /// <summary>
    /// How many seconds without frames before auto-abort kicks in
    /// </summary>
    public int autostopAfterSeconds = 30;
    
    /// <summary>
    /// The modifiers of the panic hotkey
    /// </summary>
    public KeyModifiers modifiers = DEFAULT_MODIFIERS; 

    /// <summary>
    /// The keycode of the panic hotkey
    /// </summary>
    public KeyCode keycode = DEFAULT_KEYCODE;

    /// <summary>
    /// Do we need to protect all DLLs without distinction ?
    /// </summary>
    public bool protectAllDLLs = false;

    /// <summary>
    /// The list of protected DLLs
    /// </summary>
    public LinkedList<string> protectedDLLs = new LinkedList<string>();

    /// <summary>
    /// true if the DLL activation prompt has already been displayed
    /// </summary>
    public bool displayedDLLPrompt = false;

    /// <summary>
    /// Stores the Panic Button version from which the Settings were last saved.
    /// This allows to detect updates and act accordingly.
    /// Added in 1.0.2. Older versions "1.0" and "1.0.1" lack this field.
    /// </summary>
    [System.Runtime.Serialization.OptionalField]
    public string savedVersion = "1.0.x";

    [System.Runtime.Serialization.OptionalField]
    public bool autoChangeReadOnlyAttribute = false;

    const KeyCode DEFAULT_KEYCODE = KeyCode.Escape;
    const KeyModifiers DEFAULT_MODIFIERS = KeyModifiers.Shift;


    /// <summary>
    /// Synchronization object to ensure atomicity of the Load / Save operations
    /// </summary>
    [System.NonSerialized]
    private static object _sync = new object();
    
    
    /// <summary>
    /// Prevents other classes from instantiating the Settings directly : use Load() / Save() instead
    /// </summary>
    private PanicSettings()
    {   
    }

    /// <summary>
    /// Save the provided settings to disk
    /// </summary>
    /// <param name="data">An instance of the settings</param>
    public static void Save(PanicSettings data)
    {
        var formatter = new BinaryFormatter();

        lock (_sync)
        {
            using (var f = File.Open(settingsPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(f, data);
            }
        }
    }


    /// <summary>
    /// Loads the settings from the disk
    /// </summary>
    /// <returns>an instance of the current settings of Panic Button</returns>
    public static PanicSettings Load()
    {
        PanicSettings output = null;

        lock (_sync)
        {
            if (File.Exists(settingsPath))
            {
                // Try to load the file a few times without throwing errors (just silently try it one more time instead)
                int tries = 0;
                do
                {
                    if (tries > 0)
                        System.Threading.Thread.Sleep(100);

                    output = Load_Internal(false);
                    tries++;
                } while (tries < 20 && output == null);

                // Then if it was still unsuccessfull, try one last time but throw an error this time
                if (output == null)
                    output = Load_Internal(true);
            }
            else
            {
                // If the file does not exists, we just return default settings
                output = new PanicSettings();
                
                // Ensuring that the defaults are saved to a file ensures now that the current block
                // will be executed only the first time Panic Button is installed.
                Save(output);

                Dezgo.Panic.EditorExt.EditorSystem.welcomeMessageRequested = true;

                // Trigger the workaround
                Dezgo.Panic.EditorExt.EditorSystem.workaroundProgressBar_state = 1;
            }
        }


        if(output != null)
        {
            // If we managed to load an instance of settings: we will try to transpose the agnostic keycode to a system keycode
            // and if it's impossible, this means that there is an incompatibility (maybe the keycode was set on Windows, the settings file was moved to OSX and there is no direct equivalent or vice-versa)
            // so in this case we reset to default values.
            var syscode= Dezgo.Sys.KeycodeTransposition.TransposeToSystem(output.keycode);
            if(!syscode.HasValue)
            {
                // Maybe there was some system change with the files ?
                // reset to default

                output.keycode = DEFAULT_KEYCODE;
                output.modifiers = DEFAULT_MODIFIERS; 

                Dezgo.Panic.Utils.LogWarning(Dezgo.Panic.Logging.User, "Cannot use the hotkey specified in Settings (maybe the file changed between OSX and Windows ?), use defaults: {0}", Dezgo.Sys.KeycodeTransposition.PrettyPrintHotkey(DEFAULT_MODIFIERS, DEFAULT_KEYCODE));
            }
        }


        return output;
    }

    /// <summary>
    /// Loads the settings from disk, and optionnaly throws an exception if there is an error depending on the provided parameter.
    /// </summary>
    /// <param name="throwException">if true: will throw an exception in case of a loading error</param>
    /// <returns>an instance of the settings</returns>
    private static PanicSettings Load_Internal(bool throwException)
    {
        PanicSettings output = null;

        bool upgraded= false;

        try
        {
            var formatter = new BinaryFormatter();
            using (var f = File.Open(settingsPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                // In the case that the file is empty : this means default settings
                if (f.Length == 0)
                    output = new PanicSettings();
                else
                {
                    output = (PanicSettings)formatter.Deserialize(f);
                
                    if(output.savedVersion != Dezgo.Panic.PanicButton_Version.currentVersion)
                    {
                        upgraded = true;
                    }
                }
            }

        }
        catch 
        {
            if (throwException)
                throw;
        }


        // If we detect the version has been changed, we force a reload
        if(upgraded)
        {
            output.savedVersion = Dezgo.Panic.PanicButton_Version.currentVersion;
            Save(output);
            Dezgo.Panic.Utils.Log(Dezgo.Panic.Logging.User, "upgraded to version: " + output.savedVersion);

            Dezgo.Panic.EditorExt.EditorSystem.didUpgraded = true;
        }


        return output;
    }



}
