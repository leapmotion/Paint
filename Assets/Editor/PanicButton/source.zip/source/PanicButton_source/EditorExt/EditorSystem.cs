﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System.Collections.Generic;
using System.Threading;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Dezgo.Panic.EditorExt
{
    /// <summary>
    /// This class is the general hub that orchestrates editor operations : loading settings / menus / forcing reloads / launching refactorings
    /// </summary>
    [InitializeOnLoad]
    internal static class EditorSystem
    {
        /// <summary>
        /// This is the accessor to the Settings that all subsystems must use.
        /// It automatically loads the Settings when needed and caches it in the _settings backing field.
        /// </summary>
        internal static PanicSettings Settings
        {
            get
            {
                _settings = _settings ?? PanicSettings.Load();
                return _settings;
            }

            set
            {
                _settings = value;
            }
        }
        /// <summary>
        /// This is the general field that must hold a reference to Panic Button's settings for use by all subsystems
        /// </summary>
        private volatile static PanicSettings _settings = null;
        
        /// <summary>
        /// Did a forced reload already happened during this current virtual machine instance ? (it will be reset to false when a script reload is triggered)
        /// </summary>
        static bool alreadyForcedReload = false;

        /// <summary>
        /// This timer is used to avoid checking if ScriptAssemblies are processed at every frame.
        /// </summary>
        static System.Diagnostics.Stopwatch checkScriptAssembliesProcessedStopwatch = new System.Diagnostics.Stopwatch();

        /// <summary>
        /// This is used to bypass the timer only for the first check (it must happen immediately instead of waiting for the timer)
        /// </summary>
        static bool firstCheckOfScriptAssembliesProcessed = true;

        internal volatile static bool didUpgraded = false;

        /// <summary>
        /// The first time someone installs Panic Button, we display a progress bar for 1 frame then clear it.
        /// This is a workaround for a strange bug. 
        /// If this is not done, Unity's recompilation hangs on Windows (it works fine on Mac).
        /// I found that the solution is to move the focus to another window, and then give it back to Unity's main window, and this is what the progress bar essentially does.
        /// 
        /// States:
        ///     0 : disabled, does nothing
        ///     1 : display of the progressbar requested
        ///     2 : clearing of the progressbar requested
        /// </summary>
        internal static int workaroundProgressBar_state = 0, workaround_requests=0;
        internal static bool forceReloadRequested = false;
        internal static bool displayDllOkay = false;
        internal static volatile bool welcomeMessageRequested= false; 


        static EditorSystem()
        {
            // Subscribe to Domain Unload events.
            // Refactorings must be triggered during this time, because it happens AFTER Unity has recompiled scripts (with fresh new DLLs in Library/ScriptAssemblies)
            // but BEFORE they are reloaded, so we can alter them, and have the altered versions loaded.
            System.AppDomain.CurrentDomain.DomainUnload += CurrentDomain_DomainUnload;

            // We also must be notified at each editor update to do various things like resetting the watchdog timer.
            EditorApplication.update += OnEditorUpdate;

            // Start this timer
            checkScriptAssembliesProcessedStopwatch.Start();
        }


        /// <summary>
        /// Opens the Settings editor window
        /// </summary>
        [MenuItem("Edit/Panic Button Settings")]
        static void EditSettings()
        {
            PanicSettingsEditor window = (PanicSettingsEditor)EditorWindow.GetWindow(typeof(PanicSettingsEditor));
            
            window.maximized = false;
            window.title = "Panic Button Settings";
            window.minSize = new Vector2(400, 650*0+10);

            window.ShowUtility();  
        }


        /// <summary>
        /// Forces Unity to recompile and reload scripts
        /// </summary>
        internal static void ForceReload()
        {
            if (EditorApplication.isPlaying)
                return;

            // Only one forced reload allowed by VM instance (to avoid it from looping infinitely uselessly)
            if(alreadyForcedReload)
            {
                return;
            }
            alreadyForcedReload = true;

            Utils.Log(Logging.Dev, "FORCE RELOAD!   isCompiling:{0}   isUpdating:{1}   frame:{2}", EditorApplication.isCompiling, EditorApplication.isUpdating, Time.frameCount);


            // We generate a dummy C# source file with just a random comment to force Unity to recompile and reload 

            string code = "//  " + System.Guid.NewGuid().ToString() + " " + System.DateTime.UtcNow.Ticks + "\n";
            var buf = System.Text.UTF8Encoding.UTF8.GetBytes(code);

            string path = Utils.MakePath(Utils.AssemblyDirectory, "reloader.cs");
            using (var f = System.IO.File.Open(path, System.IO.FileMode.Create, System.IO.FileAccess.Write))
            {
                f.Write(buf, 0, buf.Length);
            }

            Utils.Log(Logging.Dev, "ForceReload: file written");

            AssetDatabase.Refresh();

            Utils.Log(Logging.Dev, "ForceReload: AssetDatabase.Refresh() returned");
         
        }


        /// <summary>
        /// Raised when scripts are being reloaded, will execute a refactoring operation.
        /// </summary>
        static void CurrentDomain_DomainUnload(object sender, System.EventArgs e)
        {
            LaunchRefactoring(System.IO.Directory.GetCurrentDirectory(),
                unloading: true);
        }


        
        

        /// <summary>
        /// Called each time the editor updates.
        /// </summary>
        static void OnEditorUpdate()
        {
            if(didUpgraded)
            {
                didUpgraded = false;

                Dezgo.Panic.Refactory.forceRecompileEverything = true;
                Dezgo.Panic.EditorExt.EditorSystem.LaunchRefactoring(System.IO.Directory.GetCurrentDirectory(), false);

                Dezgo.Panic.EditorExt.EditorSystem.forceReloadRequested = true;

                return;
            }

            if(displayDllOkay)
            {
                displayDllOkay = false;

                EditorUtility.DisplayDialog("Panic Button", "DLL protection has been enabled.", "Ok");
                Interlocked.Increment(ref workaround_requests);
                ForceReload();

                return;
            }
            

            // Workaround for a strange bug: see the summary of "workaroundProgressBar_state" for details.
            if(workaroundProgressBar_state == 0 && workaround_requests > 0)
            {
                workaroundProgressBar_state = 1;
                Interlocked.Decrement(ref workaround_requests);
            }

            if (workaroundProgressBar_state == 0 && forceReloadRequested)
            {
                forceReloadRequested = false;
                ForceReload();
                var task = (new System.Threading.Thread(() =>
                {
                    System.Threading.Thread.Sleep(1000);
                    System.Threading.Interlocked.Increment(ref EditorSystem.workaround_requests);
                }));
                task.Start();
                return;
            }

            
            if(workaroundProgressBar_state == 1) 
            {
                workaroundProgressBar_state = 2;
                EditorUtility.DisplayProgressBar("Panic Button", "Installing Panic Button...", 1.0f / 1.61803398875f);
            }
            else if(workaroundProgressBar_state == 2)
            {
                workaroundProgressBar_state = 0;
                EditorUtility.ClearProgressBar();

                if (welcomeMessageRequested)
                {
                    welcomeMessageRequested = false;
                    DisplayWelcomeMessage();
                }
            }


            // If the editor is updated, this means that no script is stuck, so we can reset the watchdog timer.
            RuntimeSystem.ResetWatchdog();
            
            // Check if there is a fatal error to display
            FatalErrorWindow.ShowAlertIfAny();

          
            // Then, we will check if the ScriptAssemblies are processed : immediately the first time, and every 1000 ms thereafter.
            if (!alreadyForcedReload)
            {
                if (firstCheckOfScriptAssembliesProcessed || checkScriptAssembliesProcessedStopwatch.ElapsedMilliseconds >= 1000) 
                {
                    firstCheckOfScriptAssembliesProcessed = false;
                    checkScriptAssembliesProcessedStopwatch.Reset();
                    checkScriptAssembliesProcessedStopwatch.Start();

                    // If we detect that the current ScriptAssemblies are not processed by PanicButton (can happen the first time PanicButton is imported ; when Unity is restarted), we will force a reload
                    // (that will indirectly also cause a refactoring during the AppDomain Unload event)
                    if (!Refactory.IsScriptAssembliesProcessed())
                    {
                        Utils.LogError(Logging.Dev, "FORCE RELOAD HERE"); 
                        ForceReload();
                    }
                }
            }

        }

        private static void DisplayWelcomeMessage()
        {
            EditorUtility.DisplayDialog("Panic Button", 
                @"Thank you for installing Panic Button!

You can now press Shift+Esc to stop a stuck script.

If you enjoy Panic Button, please consider leaving a review on the Asset Store :)", 
                                                                                  "OK");

        }


        /// <summary>
        /// Does some editor-related checks to ensure that we can launch a refactoring operation, and if everything is okay, then launch it.
        /// </summary>
        /// <param name="cwd">the current working directory</param>
        /// <param name="unloading">are we in the context of an appdomain unload ?</param>
        internal static void LaunchRefactoring(string cwd, bool unloading)
        {
            try
            { 
                // 1.2.2: No longer prevent recompilation in Play mode. It was a remain of an earlier version, and this restriction is no longer relevant.
                /*if (EditorApplication.isPlaying) 
                {
                    FatalErrorWindow.SubmitAnAlert("Aborted script recompilation because we are in Play mode.\nPlease stop and restart Play mode to protect scripts with Panic Button.", toFile: unloading);
                    return;
                }*/
                if (EditorApplication.isCompiling)
                {
                    FatalErrorWindow.SubmitAnAlert("Aborted script recompilation because we are currently compiling.\nNormally this should not happen, but yet if you see this, I advise restarting Unity (just to be sure).", toFile: unloading);
                    return;
                }

                EditorApplication.LockReloadAssemblies();
                
                Settings = PanicSettings.Load();
                Dezgo.Panic.Refactory.Refactor(cwd, Settings);

                EditorApplication.UnlockReloadAssemblies();
            }
            catch(System.Exception e)
            {
                FatalErrorWindow.SubmitAnAlert("An error occured while recompiling assemblies with the Panic Button: " + e.GetType().ToString() , e.ToString() , unloading);
                Refactory.MarkScriptAssembliesAsProcessed(); // to avoid annoying auto-reloads
            }
        }
    }
}
