﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using System.IO;

namespace Dezgo.Panic.EditorExt
{
    /// <summary>
    /// This Asset Postprocessor is used to revert processed assemblies to their original state before a build.
    /// This way, the instrumentation code will not end up in production builds.
    /// </summary>
    class PanicButtonPostprocessor : AssetPostprocessor
    {
        /// <summary>
        /// This method will be called by Unity after a Build is requested but before assemblies are added to it, so this is a good time to revert them.
        /// </summary>
        public static void OnPostprocessAllAssets(
                string[] importedAssets,
                string[] deletedAssets,
                string[] movedAssets,
                string[] movedFromAssetPaths)
        {

            // Of course, this method is sometimes called outside of the context of a build (when importing Assets), 
            // so we check if we are currently in the process of building before going further.
            if (BuildPipeline.isBuildingPlayer)
            {
                // We search for every DLL file in the Assets/ folder
                foreach (var i in Dezgo.Panic.Refactory.FindDLLs("Assets") )
                {
                    if (Path.GetExtension(i) == ".dll")
                        Dezgo.Panic.Refactory.RevertAssembly(i); // and revert them
                }
            }

        }
    }
}
