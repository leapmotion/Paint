﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;


namespace Dezgo.Panic.EditorExt
{
    /// <summary>
    /// System to display fatal errors to the user.
    /// This is to let her know big errors that would probably prevent the Panic Button from working correctly, so that she won't have the assumption that it is.
    /// This way a fix can be found before a pesky infinite loop occurs.
    /// This system handles errors thrown during an Unload event by saving its data to a file, that will be read and displayed after the virtual machine has been reloaded.
    /// </summary>
    static class FatalErrorWindow 
    {
        /// <summary>
        /// General informative text displayed in each modal dialog
        /// </summary>
        static readonly string infoText = "Sorry, this problem will certainly prevent the Panic Button from working correctly.\nWe're showing you this message to let you know so that the problem can be resolved before you could be in need to use the Panic Button.\nIf you can't resolve the problem, please get in touch with our support, we'll be glad to help you ! :)\n\nYou can find details about this error in the Console (please send us this in your mail).";

        /// <summary>
        /// Messages that need to be displayed.
        /// </summary>
        static Queue<string> pendingMessage = new Queue<string>();

        /// <summary>
        /// The path to the file where messages occuring during an unload should be serialized 
        /// </summary>
        private readonly static string MESSAGE_FILE= Utils.MakePath("Library", ".dezgo.panicbutton.error.temp");

        /// <summary>
        /// Did the file was already read ? (allowed only one time per vm instance)
        /// </summary>
        static bool hasReadFile = false;

        

        /// <summary>
        /// When called, pull a message from the pending message queue OR the file and display it.
        /// Do nothing if there is no pending message.
        /// </summary>
        internal static void ShowAlertIfAny()
        {
            // If no file has been read yet, we will read it, and then call this method another time to pull this time from the in-memory queue
            bool mustCallMyself = false;

            // The message that must be displayed
            string message = null;
            
            // Pull a message from either the file or the queue
            if(!hasReadFile)
            {
                hasReadFile = true;
                mustCallMyself = true; // Ensures we do another round immediately in case there is also a message in the queue

                message = Consume_File();
            }
            else
            {
                message = Consume();
            }


            // If a message was retrieved, we display it in a modal dialog
            if (message != null)
            {
                EditorApplication.Beep();
                if (EditorUtility.DisplayDialog("Panic Button FATAL ERROR", "==> Problem: " + message + "\n\n" + infoText, "Ok", "Contact support") == false)
                {
                    PanicSettingsEditor.ContactDezgoAssetsSupport();
                }
            }
            else
            {
               if(mustCallMyself)
               {
                   ShowAlertIfAny();
               }
            }
        }

       
        /// <summary>
        /// Submit an alert that needs to be displayed.
        /// </summary>
        /// <param name="message">The message content that will be printed in the modal dialog AND in the console logs.</param>
        /// <param name="details">More details about the alert that will be printed only in the console logs.</param>
        /// <param name="toFile">If true, saves the alert in a file instead of in-memory. The file will be read and displayed at the next reload.
        /// This parameter must be set to true when an alert is submitted during an AppDomain Unload event.</param>
        internal static void SubmitAnAlert(string message, string details="", bool toFile = false)
        {           
            if(!toFile)
                Utils.LogError(Logging.User, "<!> FATAL ERROR: {0}\n\n{1}", message, details);

            // Submit the message either to the file or the queue
            if(toFile)
                Post_File(message, details);
            else
                Post(message);
        }

        /// <summary>
        /// Adds a message to be displayed in the in-memory queue
        /// </summary>
        /// <param name="message">The message to be displayed</param>
        static void Post(string message)
        {
            lock (pendingMessage)
                pendingMessage.Enqueue(message);
        }

        /// <summary>
        /// Tries to retrieve a message from the in-memory queue
        /// </summary>
        /// <returns>an error message or null if none was available</returns>
        static string Consume()
        {
            string message = null;

            lock (pendingMessage)
            {
                if (pendingMessage.Count > 0)
                {
                    message = pendingMessage.Dequeue();
                }
            }

            return message;
        }

        /// <summary>
        /// Adds a message to be displayed in the on-disk file
        /// </summary>
        /// <param name="message">The message</param>
        /// <param name="details">The details (that will be displayed only in the Console logs)</param>
        static void Post_File(string message, string details)
        {
            var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

            using (var f = System.IO.File.Open(MESSAGE_FILE, System.IO.FileMode.Create, System.IO.FileAccess.Write))
            {
                // We save the PID, this way we can check if we pulled the message from the same Unity instance or not later on.
                formatter.Serialize(f,  System.Diagnostics.Process.GetCurrentProcess().Id );

                formatter.Serialize(f, message);
                formatter.Serialize(f, details);
            }
        }

        /// <summary>
        /// Tries to retrieve a message from the file
        /// </summary>
        /// <returns>an error message or null if none was available</returns>
        static string Consume_File()
        {
            var formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            byte[] buf = null;

            try
            {
                buf = System.IO.File.ReadAllBytes(MESSAGE_FILE);
            }
            catch
            {
                return null;
            }

            System.IO.File.Delete(MESSAGE_FILE);


            var f = new System.IO.MemoryStream(buf);

            try
            {
                var pid = (int)formatter.Deserialize(f);
                var message = (string)formatter.Deserialize(f);
                var details = (string)formatter.Deserialize(f);

                // We do not display error messages from old Unity instances
                if (pid != System.Diagnostics.Process.GetCurrentProcess().Id)
                {
                    Utils.LogError(Logging.Dev, "PID mismatch, drop");
                    return null;
                }


                Utils.LogError(Logging.User, "<!> FATAL ERROR: {0}\n\n{1}", message, details);

                return message;
            }
            catch
            {
                return null;
            }
        }
    }
}
