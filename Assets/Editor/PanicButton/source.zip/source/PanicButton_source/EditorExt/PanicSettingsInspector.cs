﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;


    /// <summary>
    /// EditorWindow to edit graphically the Panic Button Settings file
    /// </summary>
    class PanicSettingsEditor : EditorWindow
    {
        /// <summary>
        /// When true, displays a warning message about the dll list being changed
        /// </summary>
        static bool displayChangedAlert = false;

        /// <summary>
        /// Are we currently waiting for a keycode ? (the input button was clicked, and the next pressed key will be selected as the main keycode for the hotkey)
        /// </summary>
        bool waitingKeycode = false;
        
        /// <summary>
        /// The currently selected DLL asset in the drap&drop field
        /// </summary>
        private static Object selectedDLL = null;

        /// <summary>
        /// The current position of the ScrollView of the window
        /// </summary>
        Vector2 scrollViewPos = Vector2.zero;

        /// <summary>
        /// The time when the EditorWindow was last repainted.
        /// </summary>
        double timeWhenLastRepaint = -1;

        /// <summary>
        /// The list of available keys to choose from to display in the selection dropdown menu
        /// </summary>
        static string[] OSX_availableKeys;

        /// <summary>
        /// Associates every key name to its OSX value
        /// </summary>
        static Dictionary<string, int> OSX_availableKeysMap = new Dictionary<string, int>();

        /// <summary>
        /// Associates every OSX value to its key name
        /// </summary>
        static Dictionary<int, string> OSX_availableKeysMap_i = new Dictionary<int, string>();

        /// <summary>
        /// The index of the current selected item in the dropdown menu (corresponds to the "OSX_availableKeys" array)
        /// </summary>
        static int dropdownSelectedKeyIndex = 0;

        /// <summary>
        /// The index of the "Escape" key in "OSX_availableKeys"
        /// </summary>
        static int indexOfEscape = -1;

        /// <summary>
        /// The style of the "Panic Button" title label
        /// </summary>
        static GUIStyle titleStyle;


        static PanicSettingsEditor()
        {
            // Build the list and maps for Mac OS X

            var notAnsiType = typeof(Dezgo.Sys.KeyTransposition_OSX.MacNotANSI);

            // Create the list of keynames to display in the dropdown menu
            var names = new List<string>(64);
            foreach (var i in System.Enum.GetNames(notAnsiType))
            {
                // Remove the "kVK_" prefix
                names.Add(i.Substring(4)); 
            }
            // Sort the name list alphabetically OR numerically if a numeric value has been found
            names.Sort((string a, string b) =>
            {
                int? foo = Dezgo.Panic.Utils.GetNumericInString(a);
                int? bar = Dezgo.Panic.Utils.GetNumericInString(b);

                if (foo.HasValue && bar.HasValue)
                {
                    return foo.Value - bar.Value;
                }
                else
                    return string.Compare(a, b);
            });

            OSX_availableKeys = names.ToArray();

            
            // Now associate each value to its name and vice-versa
            foreach(var i in System.Enum.GetValues(notAnsiType))
            {
                // Remove the "kVK_" prefix
                var name = System.Enum.GetName(notAnsiType, i).Substring(4);

                OSX_availableKeysMap[name]= (int)i;
                OSX_availableKeysMap_i[(int)i] = name;
            }

            // Find the index of the "Escape" key in case we need to reset to a default 
            indexOfEscape = (new List<string>(OSX_availableKeys).FindIndex((string a) => a == "Escape"));
        }

        /// <summary>
        /// Opens the default email program with the address to the support of Dezgo Assets
        /// </summary>
        internal static void ContactDezgoAssetsSupport()
        {
            Application.OpenURL("mailto:asset-support@dezgo.com");
        }


        /// <summary>
        /// Draws a graphical horizontal separation line
        /// </summary>
        static void Separator()
        {
            EditorGUILayout.Space();
            GUILayout.Box("", GUILayout.ExpandWidth(true), GUILayout.Height(1));
            EditorGUILayout.Space();
        }

        /// <summary>
        /// Begins a horizontally centered area
        /// </summary>
        static void BeginCenter()
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
        }

        /// <summary>
        /// Ends a horizontally centered area
        /// </summary>
        static void EndCenter()
        {
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }



        public PanicSettingsEditor()
        {
            this.autoRepaintOnSceneChange = true;
        }


        void Update()
        {
            // Ensures the window is repainted once in a while

            double now = EditorApplication.timeSinceStartup;

            if(now - timeWhenLastRepaint >= 1)
            {
                timeWhenLastRepaint = now;
                Repaint();
            }
        }



        void OnGUI()
        {
            // Load the latest data
            var data = PanicSettings.Load();

            // Initialize this style if not already
            if(titleStyle == null)
            {
                titleStyle = new GUIStyle(GUI.skin.label);
                titleStyle.fontSize = 30;
            }

           
            scrollViewPos = EditorGUILayout.BeginScrollView(scrollViewPos, false, true, GUIStyle.none, GUI.skin.verticalScrollbar, GUIStyle.none);
            BeginCenter();
            EditorGUILayout.BeginVertical(GUILayout.Width((int)(this.position.width*.90)));
           

            BeginCenter();
            GUILayout.Label("Panic Button", titleStyle);
            EndCenter();


            BeginCenter();
            if(GUILayout.Button("Developed by William Harel (@willharel)"))
            {
                Application.OpenURL("https://twitter.com/willharel");
            }
            EndCenter();

            BeginCenter();
            GUILayout.Label("Version: "+ (data.savedVersion ?? "1.0.x")+" - © 2015 Dezgo SAS");
            EndCenter();


            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Contact support"))
            {
                ContactDezgoAssetsSupport();
            }
            if (GUILayout.Button("Go to Dezgo.com"))
            {
                Application.OpenURL("http://dezgo.com/assets/");
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            Separator();
            EditorGUILayout.Space();


            EditorGUILayout.LabelField("Hotkey:");

            // We capture if the hotkey selection changed to force saving the data
            bool hotkeySelectionChanged = DrawHotkeySelector(data);

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("Press the \"Panic Button\" hotkey defined above, and this will abort any malfunctionning script.", MessageType.Info);



            EditorGUILayout.Space();
            Separator();
            EditorGUILayout.Space();




            data.enableAutostop = EditorGUILayout.Toggle("Enable Auto-abort ?", data.enableAutostop);

            
            data.autostopAfterSeconds = EditorGUILayout.IntField("Max seconds", data.autostopAfterSeconds);
            if (data.autostopAfterSeconds < 1)
                data.autostopAfterSeconds = 1;

            if (data.autostopAfterSeconds >= 60)
                EditorGUILayout.HelpBox("Are you sure you want to set Auto-abort to such a high value ? This might prevent you from getting back in the Editor fast if things go wrong.", MessageType.Warning);

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("If Auto-abort is enabled, each script that is freezing longer than the specified time limit will be automatically aborted." +
            "\n\nNOTE: Auto-abort is only active in Play mode ! For Editor scripts, you must use the Panic hotkey.", MessageType.Info);



            EditorGUILayout.Space();
            Separator();
            EditorGUILayout.Space();


            DrawProtectedDLL(data);



            EditorGUILayout.EndVertical();
            EndCenter();
            EditorGUILayout.EndScrollView();
            
            if (GUI.changed || hotkeySelectionChanged)
            {
                PanicSettings.Save(data);
                Dezgo.Panic.EditorExt.EditorSystem.Settings = data;
            }
        }

        /// <summary>
        /// Can we add this path to the list of protected DLLs ?
        /// </summary>
        /// <param name="data">an instance of the settings</param>
        /// <param name="path">a path to a file</param>
        /// <returns>true if the file at "path" is : a dll, and not already added to "data"</returns>
        private bool IsAddableAssetDLL(PanicSettings data, string path)
        {
            if (System.IO.Path.GetExtension(path) == ".dll")
            {
                if (!data.protectedDLLs.Contains(path))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Called when Unity had reloaded scripts
        /// </summary>
        [UnityEditor.Callbacks.DidReloadScripts()]
        static void OnReload()
        {
            // Scripts had been reloaded, so we no longer need to display this message
            displayChangedAlert = false;
        }
        /// <summary>
        /// Draws the "DLL PROTECTION" section
        /// </summary>
        private void DrawProtectedDLL(PanicSettings data)
        {
            bool hasChanged = false;

            BeginCenter();
            GUILayout.Label("DLL PROTECTION");
            EndCenter();

            EditorGUILayout.Space();


            if (displayChangedAlert)
            {
                EditorGUILayout.HelpBox("The list of DLLs has been modified. Changes will reflect after the next Unity script compilation.", MessageType.Warning);
                EditorGUILayout.Space();
            }

            {
                var oldValue = data.protectAllDLLs;
                data.protectAllDLLs = EditorGUILayout.Toggle("Protect all DLLs :", data.protectAllDLLs);
                if (data.protectAllDLLs != oldValue)
                    hasChanged = true;
            }

            EditorGUILayout.Space();

            data.autoChangeReadOnlyAttribute = EditorGUILayout.Toggle("Protect even if read-only", data.autoChangeReadOnlyAttribute);

            EditorGUILayout.Space();
            
            GUILayout.Label("List of protected DLLs :\n(drag&drop on the top field to add a new one)");


            bool wasNull = selectedDLL == null;
            selectedDLL = EditorGUILayout.ObjectField("", selectedDLL, typeof(Object));

            // If a new asset has been selected
            if (wasNull && selectedDLL != null)
            {
                var path = AssetDatabase.GetAssetPath(selectedDLL);

                if (IsAddableAssetDLL(data, path))
                {
                    data.protectedDLLs.AddFirst(path);
                    hasChanged = true;
                }

                selectedDLL = null;
            }

            // Sort the list of protected DLLs by filename ignoring the case
            var listOfDLLs = new List<string>(data.protectedDLLs);
            listOfDLLs.Sort((string a, string b) =>
                System.StringComparer.InvariantCultureIgnoreCase.Compare(System.IO.Path.GetFileName(a), System.IO.Path.GetFileName(b))
             );

            // List of dlls to add or delete after we finish the iteration
            var toDelete = new List<string>();
            var toAdd = new List<string>();

            foreach (var iteratedDLLPath in listOfDLLs)
            {
                GUILayout.BeginHorizontal();

                // Display this item in an ObjectField, so that it can be changed by the user
                Object newAsset = EditorGUILayout.ObjectField(AssetDatabase.LoadAssetAtPath(iteratedDLLPath, typeof(Object)), typeof(Object));
                if (newAsset != null)
                {
                    var newPath = AssetDatabase.GetAssetPath(newAsset);
                    if (newPath != iteratedDLLPath)
                    {
                        if (IsAddableAssetDLL(data, newPath))
                        {
                            // If we detect a change in this field, we delete the old value and add the new one
                            toDelete.Add(iteratedDLLPath);
                            toAdd.Add(newPath);
                        }
                    }
                }

                // Display the button that allows the user to delete this item
                if (GUILayout.Button("X", GUILayout.Width(50)))
                    toDelete.Add(iteratedDLLPath);

                GUILayout.EndHorizontal();
            }


            // Finally, once the iteration is completed, we make the changes

            foreach (var addedDLL in toAdd)
            {
                if (!data.protectedDLLs.Contains(addedDLL))
                {
                    data.protectedDLLs.AddFirst(addedDLL);
                    hasChanged = true;
                }
            }
            foreach (var deletedDLL in toDelete)
            {
                data.protectedDLLs.Remove(deletedDLL);
                hasChanged = true;
            }

            // If the list of protected DLL files has changed, we need to display the "changed alert" message to the user
            // and force Refactory to recompile everything (disables the cache)
            if (hasChanged)
            {
                displayChangedAlert = true;
                Dezgo.Panic.Refactory.forceRecompileEverything = true;
            }


            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("By default, Panic Button allows you to abort scripts that you write directly in your project as C#, JavaScript or Boo source files.\n\n" +
                "If you are developping code as a separate DLL and you want to enable the protection on it, you need to add it in the above list or to enable protection on all DLLs.\n" +
                "If an infinite loop occurs in one of the selected DLLs, the Panic Button will then be able to abort the " +
             "currently executing DLL.\n\n" +
             "Please note that in order to work, this functionnality needs to patch your DLL. The patch is automatically removed when you export a build or if you remove the DLL from the above list."
             + "\n\nThis functionnality is applicable only for managed .NET libraries!\nDo not select a native code library or one that is targeted to platforms other than the Editor.", MessageType.Info);
        }


        /// <summary>
        /// Draws the selector of the hotkey
        /// </summary>
        /// <returns>true if the setting was changed</returns>
        private bool DrawHotkeySelector(PanicSettings data)
        {
            bool wasChanged = false;



            /*** MODIFIERS ***/

            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();

            // The output of the GUI will be composed in this field, one bit at a time
            PanicSettings.KeyModifiers endresult = 0;

            // Create a list of all the modifiers indexed by their name
            var modifiersList = new Dictionary<string, PanicSettings.KeyModifiers>();
            foreach (var val in System.Enum.GetValues(typeof(PanicSettings.KeyModifiers)))
            {
                modifiersList[System.Enum.GetName(typeof(PanicSettings.KeyModifiers), val)] = (PanicSettings.KeyModifiers)val;
            }


            EditorGUILayout.BeginVertical();
            foreach (var i in modifiersList)
            {
                // Calculate if the bit of this modifier is currently set (to determine if we display it checked in the GUI toggle)
                bool isCurrentlySet = (data.modifiers & i.Value) != 0;

                var displayedName = i.Key;
                if (i.Value == PanicSettings.KeyModifiers.System)
                {
                    displayedName = Dezgo.Sys.KeycodeTransposition.GetFriendlySystemKeyName();
                }

                // Display the toggle
                if (EditorGUILayout.Toggle(displayedName, isCurrentlySet))
                {
                    // If the toggle is checked, flip the bit on in the endresult
                    // (we do nothing if it's not, because all bits of endresult are initialized to 0)
                    endresult |= i.Value;
                }
            }

            // Once the modified (or not) endresult bitfield is finished, we assign it to the "modifiers" field of the settings
            data.modifiers = endresult;

            EditorGUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("+");
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();



            /*** MAIN KEYCODE ***/
         
            // Currently, the main keycode selection is different on Windows and Mac OS X.

            // On Windows, we display a simple button that can be clicked, and then we capture the keycode reported by the Unity Input system.
            
            // On OSX, this is not that simple, because the keycode reported by Unity reflects correctly the layout of the keyboard, but the Carbon registration not...
            // So this means that if Unity reports "A", and we set kVK_ANSI_A to Carbon, the key that will actually be registered may be "Q" instead if we are on 
            // an AZERTY keyboard.
            // So for now, on OSX, until a fix is found, we just display a dropdown menu that allows to select the keys
            // that are not affected by this problem (all kVK keys without "ANSI")
            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                // If we were waiting for a keypress and we got one
                if (waitingKeycode && Event.current.type == EventType.KeyDown)
                {
                    if (Event.current.isKey)
                    {
                        if (Event.current.keyCode != KeyCode.None)
                        {
                            var unityKeycode = Event.current.keyCode;

                            var syscode = Dezgo.Sys.KeycodeTransposition.TransposeToSystem(unityKeycode);

                            // check that it is transposable before accepting it
                            if (syscode.HasValue)
                            {
                                // Assign it to the settings
                                data.keycode = unityKeycode;
                                waitingKeycode = false;
                                wasChanged = true;
                                base.Repaint();
                            }
                        }
                    }
                }

                // Display the button
                if (waitingKeycode)
                {
                    if (GUILayout.Button("[Please press a key]"))
                    {

                    }
                }
                else
                {
                    string keyTxt = "NULL";

                    var unityCode = data.keycode;

                    keyTxt = unityCode.ToString();

                    if (GUILayout.Button(keyTxt + "   (click to change)"))
                    {
                        waitingKeycode = true;
                    }
                }

            }
            else if(Application.platform == RuntimePlatform.OSXEditor)
            {
                var systemCode =  (int)Dezgo.Sys.KeycodeTransposition.TransposeToSystem( data.keycode ) ;
                
                // Find the "selectedIndex" of the GUI Popup from the list of available keys
                dropdownSelectedKeyIndex = -1;
                for(var i= 0 ;  i < OSX_availableKeys.Length;  i++)
                {
                    string key = OSX_availableKeys[i];
                    if(OSX_availableKeysMap.ContainsKey(key))
                    {
                        int v = OSX_availableKeysMap[key];
                        if (v == systemCode)
                        {
                            dropdownSelectedKeyIndex = i;
                            break;
                        }      
                    }  
                }
                // select a default key if we do not find (ex: a windows settings file being transfered to a mac ...)
                if(dropdownSelectedKeyIndex == -1)
                {
                    if (indexOfEscape == -1)
                        dropdownSelectedKeyIndex = 0;
                    else
                        dropdownSelectedKeyIndex = indexOfEscape;
                }

                // Display the dropdown menu
                dropdownSelectedKeyIndex= EditorGUILayout.Popup(dropdownSelectedKeyIndex, OSX_availableKeys);

                var selectedSysCode = OSX_availableKeysMap[OSX_availableKeys[dropdownSelectedKeyIndex]];
                
                KeyCode? selectedUnityCode = Dezgo.Sys.KeycodeTransposition.TransposeToUnity((uint)selectedSysCode);
                if (selectedUnityCode.HasValue)
                {
                    data.keycode = selectedUnityCode.Value;
                    wasChanged = true;
                }
            }


            return wasChanged;
        }
    }
