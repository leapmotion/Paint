﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using UnityEngine;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Linq;

namespace Dezgo.Panic
{
    /// <summary>
    /// The "runtime" of Panic Button.
    /// It receives frequent calls from the scripts to a "Probe" method where it has a chance to abort them by throwing an exception.
    /// It decides when scripts should be aborted using a watchdog and a panic hotkey.
    /// </summary>
    [UnityEditor.InitializeOnLoad]
    public static class RuntimeSystem
    {
        /// <summary>
        /// The filename of the helper program for Mac OS X.
        /// </summary>
        internal static readonly string MAC_PROGRAM_FILENAME = "MacHotKeys";

        /// <summary>
        /// A reference to Unity's main thread
        /// </summary>
        static volatile Thread unityThread = null;

        /// <summary>
        /// The thread responsible for checking the expiration of the watchdog timer
        /// </summary>
        static volatile Thread watchdogThread = null;

        /// <summary>
        /// The thread responsible for detecting panic hotkey presses
        /// </summary>
        static volatile Thread panicThread = null;

        /// <summary>
        /// The timer that must be reset at every frame
        /// </summary>
        static Stopwatch watchdogTimer = new Stopwatch();

        /// <summary>
        /// This switch must be set to true by either the watchdogThread or panicThread to trigger an abort.
        /// </summary>
        public static volatile bool expired = false;

        /// <summary>
        /// When "expired" is triggered by the watchdogThread, this bool is set to true
        /// </summary>
        static volatile bool fromAutoAbort = false;

        /// <summary>
        /// When "expired" is triggered by the panicThread, this bool is set to true
        /// </summary>
        static volatile bool fromHotkey = false;

        /// <summary>
        /// The message that must be included in the PanicAbortException.
        /// This field is set by the two control threads.
        /// </summary>
        static string expirationString = "";
        
        /// <summary>
        /// The ID of the hotkey to register with IHotKey. 
        /// </summary>
        private const int HOTKEY_ID = 42; // This value must be carefully chosen. So only a great value like 42 is fit for the job.

        /// <summary>
        /// The current running platform
        /// </summary>
        static RuntimePlatform applicationPlatform;
        


        /// <summary>
        /// Shortcut to the settings in the EditorSystem
        /// </summary>
        static PanicSettings Settings
        {
            get
            {
                return EditorExt.EditorSystem.Settings;
            } 
        }
        

      

        static RuntimeSystem()
        {
            Utils.Log(Logging.Dev, "Start RuntimeSystem");
            
            applicationPlatform = Application.platform;

            // Start the watchdog timer
            lock (watchdogTimer)
                watchdogTimer.Start();


            // Start control threads

            watchdogThread = new Thread(WatchdogProcedure);
            watchdogThread.IsBackground = true;
            watchdogThread.Start();

            panicThread = new Thread(PanicProcedure);
            panicThread.IsBackground = true;
            panicThread.Start();
        }


        /// <summary>
        /// Control aborts by detecting panic hotkey presses
        /// </summary>
        static void PanicProcedure()
        {
            try
            {
                // Instantiate the correct IHotKey implementation depending on the system
                
                Dezgo.Sys.IHotKey dispatcher = null;

                switch (applicationPlatform)
                {
                    case RuntimePlatform.WindowsEditor:
                        dispatcher = new Dezgo.Sys.WindowsHotkey();
                        break;

                    case RuntimePlatform.OSXEditor:
                        dispatcher = new Dezgo.Sys.ProcessHotKey( Utils.MakePath(Utils.AssemblyDirectory , MAC_PROGRAM_FILENAME));
                        break;

                    default:
                        throw new System.NotSupportedException("This platform is not supported by the Panic Button: " + applicationPlatform.ToString());
                        break;
                }

                // Wrap it with a Logger
                dispatcher = new Dezgo.Sys.HotKey_Logger(dispatcher);

                // Translate system-agnostic codes to system-specific codes
                var p1 = Dezgo.Sys.KeycodeTransposition.TransposeToSystem_Modifiers(Settings.modifiers);
                var p2 = Dezgo.Sys.KeycodeTransposition.TransposeToSystem(Settings.keycode);

                // And ... register the hotkey with the system
                dispatcher.Register(HOTKEY_ID, p1.Value, p2.Value, Panic_HotkeyPressedHandler);


                // Run the event loop
                while (dispatcher.WaitNext())
                {
                    Thread.Sleep(98);

                    // If the hotkey settings have been changed, re-register the keycodes
                    var np1 = Dezgo.Sys.KeycodeTransposition.TransposeToSystem_Modifiers(Settings.modifiers);
                    var np2 = Dezgo.Sys.KeycodeTransposition.TransposeToSystem(Settings.keycode);

                    if (np1 != p1 || np2 != p2)
                    {

                        dispatcher.Register(HOTKEY_ID, np1.Value, np2.Value, Panic_HotkeyPressedHandler);
                        p1 = np1;
                        p2 = np2;
                    }
                }
            }
            catch (System.Threading.ThreadAbortException)
            {
                // No-op
                // Sometimes this is thrown when Unity reloads the scripts
            }
            catch (System.Exception e)
            {
                Dezgo.Panic.EditorExt.FatalErrorWindow.SubmitAnAlert("An exception has been raised in the Panic thread: " + e.GetType().ToString() + "\n\nTry to recompile scripts or to restart Unity."
                    , e.ToString(), false);
            }         
        }


        /// <summary>
        /// Callback method called when a hotkey press has been detected
        /// </summary>
        static void Panic_HotkeyPressedHandler()
        {
            lock (watchdogTimer)
            {
                // Abort !

                expirationString = "";
                fromHotkey = true;
                expired = true; 
            }
        }


        /// <summary>
        /// Control aborts by detecting if the watchdog timer has expired
        /// </summary>
        static void WatchdogProcedure()
        {
            try
            {
                // Check if the timer has expired every now and then
                while (true)
                {
                    Thread.Sleep(250);

                    // Settings
                    bool isEnabled = true;
                    int seconds = 5;

                    // Retrieve settings
                    if (EditorExt.EditorSystem.Settings != null)
                    {
                        isEnabled = EditorExt.EditorSystem.Settings.enableAutostop;
                        seconds = EditorExt.EditorSystem.Settings.autostopAfterSeconds;
                    }

                    if (isEnabled)
                    {
                        lock (watchdogTimer)
                        {

                            if (watchdogTimer.ElapsedMilliseconds >= seconds * 1000)
                            {
                                // Abort !

                                expirationString = string.Format("Script expired after more than {0} seconds without updates", seconds);

                                fromAutoAbort = true;
                                expired = true;
                            }

                        }
                    }


                }
            }
            catch (ThreadAbortException)
            {
                
            }
            catch(System.Exception e)
            {
                Dezgo.Panic.EditorExt.FatalErrorWindow.SubmitAnAlert("An exception has been raised in the Watchdog thread: " + e.GetType().ToString() + "\n\nTry to recompile scripts or to restart Unity."
                    , e.ToString(), false);
            }
        }


        
        /// <summary>
        /// The probe method that is called by scripts at each control flow change.
        /// If an abort has been triggered by one of the control threads, it will throw a PanicAbortException and pause the game.
        /// </summary>
        public static void Probe()
        {
            // To minimize the performance impact, this method is as short as possible.

            if (expired)
                DoExpired();
        }

        [System.ThreadStatic]
        static bool isDoExpiredActive = false;

        /// <summary>
        /// Called by Probe() when an Abort needs to be done.
        /// </summary>
        public static void DoExpired()
        {
            if (isDoExpiredActive) return;
            isDoExpiredActive = true;

            try {

                // If the Unity thread has not yet been detected, try to find out if the currently executing thread is Unity main thread.
                if (unityThread == null)
                {
                    try
                    {
                        int frame = Time.frameCount; // can only be called from Unity main thread
                        unityThread = Thread.CurrentThread;
                    }
                    catch (System.ArgumentException e)
                    {
                        // Not the unity thread ...
                        return;
                    }
                }

                // Check that we are running from the Unity thread to abort (background threads may continue freely)
                if (Thread.CurrentThread != unityThread)
                    return;

                // Reset the watchdog if it expired when not in Play mode, and return
                if (!UnityEditor.EditorApplication.isPlaying)
                {
                    if (fromAutoAbort)
                    {
                        lock (watchdogTimer)
                        {
                            fromAutoAbort = false;
                            expired = false;
                            watchdogTimer.Reset(); watchdogTimer.Start();
                        }

                        return;
                    }
                }

                lock (watchdogTimer)
                {
                    // Reset the watchdog timer 
                    watchdogTimer.Reset();

                    // Reset flags
                    fromAutoAbort = false;
                    fromHotkey = false;
                    //expired = false; // 1.2.1: Continue to throw until an update is received, so we don't reset this field now

                    // Pause the game
                    if (UnityEditor.EditorApplication.isPlaying)
                    {
                        UnityEngine.Debug.Break();
                    }


                    // Abort the script by throwing an exception
                    //Utils.LogError(Logging.User, "ABORT STACK TRACE:\n{0}\n\n\n", System.Environment.StackTrace);

                    throw new PanicAbortException(expirationString);
                }
            }
            finally
            {
                isDoExpiredActive = false;
            }
        }

        /// <summary>
        /// Resets the watchdog. Must be called at every frame from the Unity thread.
        /// </summary>
        internal static void ResetWatchdog()
        {
            // 1.2.1: reset the last exception
            PanicAbortException.firstOfFrame = null;

            // Capture the current thread as the Unity thread
            unityThread = unityThread ?? Thread.CurrentThread;
 
            lock (watchdogTimer)
            {
                if (expired)
                {
                    if(UnityEditor.EditorApplication.isPlaying)
                    {
                        UnityEngine.Debug.Break();
                    }
                }

                expired = false;
                watchdogTimer.Reset(); expired = false;
                watchdogTimer.Start(); expired = false;
            } 
        }

    }
}
