﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;

namespace Dezgo.Panic
{
    /// <summary>
    /// Logging level type.
    /// User logs are displayed all the time.
    /// Dev logs are reserved for developement and must be discarded in release.
    /// </summary>
    internal enum Logging { User, Dev };

    

    /// <summary>
    /// Miscellaneous helper and utility methods
    /// </summary>
    static class Utils
    {
        

        static Utils()
        {
            
        }

        /// <summary>
        /// Return the directory in which the Panic Button assembly is stored.
        /// This allows to move Panic Button in a different folder.
        /// Thanks to Alexey Khoroshilov for the suggestion!
        /// </summary>
        internal static string AssemblyDirectory
        {
            get
            {
                var assemblyFile = System.Reflection.Assembly.GetExecutingAssembly().Location;

                // Detect if the file location has been changed by the user
                if(!File.Exists(assemblyFile))
                {
                    bool didFallback = false;

                    // If so, search subdirectories and fallback to this
                    foreach(var f in Refactory.FindDLLs("Assets"))
                    {
                        if(Path.GetFileName(f) == Path.GetFileName(assemblyFile))
                        {
                            assemblyFile = f;
                            didFallback = true;
                            break;
                        }
                    }

                    if (!didFallback)
                    {
                        // If we reach this point, then this means that Panic Button has been uninstalled
                        // TODO: create a user-friendly uninstall system
                    }
                }

                return Path.GetDirectoryName(assemblyFile);
            }
        }



        // These methods are a workaround for older Unity versions that don't have LogFormat methods:

        static void LogFormat(string format, params object[] p)
        {
            Debug.Log(string.Format(format, p));
        }

        static void LogWarningFormat(string format, params object[] p)
        {
            Debug.LogWarning(string.Format(format, p));
        }

        static void LogErrorFormat(string format, params object[] p)
        {
            Debug.LogError(string.Format(format, p));
        }



        // Then this is the public-facing versions that filter Debug logs and add a prefix depending on logType:

        public static void Log(Logging logType, string format, params object[] p)
        {
            if (logType == Logging.Dev) return;
            LogFormat(LogPrefix(logType)  + format + LogPostfix(), p);
        }

        public static void LogWarning(Logging logType, string format, params object[] p)
        {
            if (logType == Logging.Dev) return;
            LogWarningFormat(LogPrefix(logType) + format + LogPostfix(), p);
        }

        public static void LogError(Logging logType, string format, params object[] p)
        {
            if (logType == Logging.Dev) return;
            LogErrorFormat(LogPrefix(logType) + format + LogPostfix(), p);
        }


        static string LogPostfix()
        {
            return "\n===\nPanic Button version: " + PanicButton_Version.currentVersion;
        }


        /// <summary>
        /// Returns the prefix that must be added to a log depending on its logType
        /// </summary>
        /// <param name="logType"></param>
        /// <returns></returns>
        static string LogPrefix(Logging logType)
        {
            return (logType == Logging.User) ? "PanicButton: " : "PanicButton: DEBUG: ";
        }


        /// <summary>
        /// Combine multiple filesystem path elements using the system separator
        /// </summary>
        /// <param name="items">separate path elements</param>
        /// <returns>the combined path from the elements in "items" using the system separator</returns>
        public static string MakePath(params string[] items)
        {
            string output = null;

            foreach (var i in items)
            {
                if (output == null)
                    output = i;
                else
                    output = Path.Combine(output, i);
            }

            return output;
        }

        /// <summary>
        /// Returns the SHA-256 of the input
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        internal static byte[] ComputeHash(byte[] input)
        {
            var h = new System.Security.Cryptography.SHA256CryptoServiceProvider();

            return h.ComputeHash(input);
        }

     

        /// <summary>
        /// Writes all the content of a Stream to another one.
        /// </summary>
        /// <param name="from">origin Stream</param>
        /// <param name="to">destination Stream</param>
        internal static void CopyTo(Stream from, Stream to)
        {
            byte[] buffer = new byte[4096];
            int read;

            while ((read = from.Read(buffer, 0, buffer.Length)) > 0)
            {
                to.Write(buffer, 0, read);
            }
        }

        /// <summary>
        /// Reads the Stream to the end and return the data as a byte array
        /// </summary>
        /// <param name="stream">the Stream to read from</param>
        /// <returns>a byte[] array with all the contents of the input Stream</returns>
        internal static byte[] ReadAllBytes(Stream stream)
        {
            var data = new byte[stream.Length];
            stream.Read(data, 0, data.Length);    
            return data;
        }

        /// <summary>
        /// Returns the numeric value of a string. Or null if no numeric value could be parsed in the string.
        /// This works even if some characters are not digits by stripping all non-digit characters.
        /// </summary>
        /// <param name="inputString">the string from which a numeric value should be extracted</param>
        /// <returns>an integer representing the numeric value in the string or null if parsing failed</returns>
        internal static int? GetNumericInString(string inputString)
        {
            string num = "";

            // Filters all digits in the string
            foreach(var c in inputString)
            {
                if(char.IsDigit(c))
                {
                    num += c;
                }
            }

            // Then attempts to parse
            if (num != "")
            {
                int result;
                if (int.TryParse(num, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out result))
                    return result;
                else
                    return null;
            }
            else
                return null;
        }
    }
}
