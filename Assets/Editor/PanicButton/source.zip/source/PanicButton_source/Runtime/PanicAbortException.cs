﻿/* Copyright (c) 2015 Dezgo SAS
 * Distributed under the terms of Unity's ASSET STORE END USER LICENSE AGREEMENT.
 * https://unity3d.com/legal/as_terms
 * 
 * PANIC BUTTON
 * Editor extension for Unity - safeguards your scripts from infinite loops
 * 
 * Developed by: William Harel (https://twitter.com/willharel)
 * Contact:      asset-support@dezgo.com
 * 
 * http://dezgo.com/
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dezgo.Panic
{
    /// <summary>
    /// The exception that is thrown by the Panic Button within a script when it needs to be aborted
    /// </summary>
    public class PanicAbortException : Exception
    {
        // 1.2.1
        /// <summary>
        /// Contains the first thrown instruction at the start of the current frame (reset to null at every editor update).
        /// This allows to keep info of the first exception that was thrown in case PB had to throw multiple exceptions
        /// to fully halt the scripting engine (in case of catch/finally handlers)
        /// </summary>
        internal static PanicAbortException firstOfFrame = null;

        
        public PanicAbortException(string msg)
            : base(msg)
        {
            //if (firstOfFrame == null)
            //    firstOfFrame = this;
            
            System.Threading.Interlocked.CompareExchange(ref firstOfFrame, this, null);

            // TODO: create a nice 'dev' log that I can ask for in case of a support request
            /*using (var f = System.IO.File.Open("panicbutton.abortexception.log", System.IO.FileMode.Append, System.IO.FileAccess.Write, System.IO.FileShare.ReadWrite))
            {
                using (var writer = new System.IO.StreamWriter(f))
                {
                    writer.WriteLine(Environment.StackTrace);
                }
            }*/

            
            Utils.LogWarning(Logging.Dev, "Create new PanicAbortException at:\n{0}", System.Environment.StackTrace);
        }

        public override string StackTrace
        {
            get
            {
                var original = firstOfFrame;

                // 1.2.1
                if(this != original)
                {
                    return original.StackTrace;
                }

                // Simplify the stacktrace by removing frames about Panic Button itself
                var frames=  base.StackTrace.Replace("\r", "").Split('\n');
                return string.Join("\n", frames, 1, frames.Length - 1);
            }
        }
    }
}
