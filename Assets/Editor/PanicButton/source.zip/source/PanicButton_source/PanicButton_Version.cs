﻿namespace Dezgo.Panic
{
    internal static class PanicButton_Version
    {
        public static readonly string currentVersion = "1.2.3";

        public static byte[] AsByteArray
        {
            get
            {
                return System.Text.UTF8Encoding.UTF8.GetBytes(currentVersion);
            }
        }
    }
}
